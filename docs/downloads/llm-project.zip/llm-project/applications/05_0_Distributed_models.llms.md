# Distributed models examples

Author

Affiliations

François-David Collin [](mailto:francois-david.collin@umontpellier.fr)

CNRS

IMAG

Paul-Valéry Montpellier 3 University

# Prerequisites

You will need to install `dask[complete]` and `graphviz` packages.

# Initialization

Code

``` python
from dask.distributed import LocalCluster
cluster = LocalCluster(n_workers=8, threads_per_worker=1)          # Fully-featured local Dask cluster
client = cluster.get_client()
client
```

    /Users/fradav/Documents/Dev/Python/Cours-programmation-MIASHS-2025/.venv/lib/python3.13/site-packages/distributed/node.py:187: UserWarning:

    Port 8787 is already in use.
    Perhaps you already have a cluster running?
    Hosting the HTTP server on port 60498 instead

### Client

Client-d5f4cf2e-8a01-11f0-84a3-537078e81fb3

|  |  |
|:---|:---|
| **Connection method:** Cluster object | **Cluster type:** distributed.LocalCluster |
| **Dashboard:** [http://127.0.0.1:60498/status](http://127.0.0.1:60498/status) |  |

### Cluster Info

### LocalCluster

a0429074

|  |  |
|:---|:---|
| **Dashboard:** [http://127.0.0.1:60498/status](http://127.0.0.1:60498/status) | **Workers:** 8 |
| **Total threads:** 8 | **Total memory:** 64.00 GiB |
| **Status:** running | **Using processes:** True |

### Scheduler Info

### Scheduler

Scheduler-ce887903-8d52-4e41-87cb-1745afeadd3e

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:60499 | **Workers:** 0 |
| **Dashboard:** [http://127.0.0.1:60498/status](http://127.0.0.1:60498/status) | **Total threads:** 0 |
| **Started:** Just now | **Total memory:** 0 B |

### Workers

#### Worker: 0

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:60522 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:60526/status](http://127.0.0.1:60526/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:60502 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-ceyv5a9i |  |

#### Worker: 1

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:60523 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:60527/status](http://127.0.0.1:60527/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:60504 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-93ocvxjj |  |

#### Worker: 2

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:60524 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:60530/status](http://127.0.0.1:60530/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:60506 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-n9ujfi_j |  |

#### Worker: 3

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:60525 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:60532/status](http://127.0.0.1:60532/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:60508 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-5c0rmvaz |  |

#### Worker: 4

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:60534 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:60536/status](http://127.0.0.1:60536/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:60510 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-378oumvf |  |

#### Worker: 5

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:60535 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:60540/status](http://127.0.0.1:60540/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:60512 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-ulo_tw_i |  |

#### Worker: 6

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:60538 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:60542/status](http://127.0.0.1:60542/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:60514 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-wno5ajc6 |  |

#### Worker: 7

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:60539 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:60544/status](http://127.0.0.1:60544/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:60516 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-dfjafru9 |  |

## Distributed prime numbers

Let’s revive our functions

Code

``` python
import math

def check_prime(n):
    if n % 2 == 0:
        return False
    for i in range(3, int(math.sqrt(n)) + 1, 2):
        if n % i == 0:
            return False
    return True
```

Code

``` python
def chunks(lst, n):
    """Yield successive n-sized chunks from lst."""
    for i in range(0, len(lst), n):
        yield lst[i:i + n]
```

Code

``` python
import numpy as np

def find_primes(r):
    return np.array(list(filter(check_prime,r)))
```

### First steps

1.  Complete with the correct Dask code the function below which:
    - takes a maximum number `N` and a `chunksize` as arguments
    - creates a Dask `array` with numbers from 1 to `N` split into `chunksize` chunks
    - maps the `find_primes` function to each chunk
    - returns the resulting Dask array

See [Dask Array documentation](https://docs.dask.org/en/stable/array.html).

``` python
import dask.array as da

def calculate_primes(N,chunksize):
    arr = ...
    return arr....
```

2.  Benchmark it for

``` python
N = 5000000
```

Code

``` python
N = 5000000
```

Code

``` python
compute_graph = calculate_primes(N,8)
compute_graph
```

[TABLE]

3.  Visualize the computation graph

# An embarrassingly parallel example : distributed Monte-Carlo computing of \pi

If we sample randomly a bunch of N points in the unity square, and counts all points N_I verifying the condition

x^2 + y^2 \le 1 which means they are in the upper right quarter of a disk.

We have this convergence

\lim\_{N\to\infty} 4\frac{N_I}{N} = \pi

![](attachment:hpp2_0901.png)

### 2. Write the function which :

- takes a number of estimates `nbr_estimates` as argument
- samples them in the \[(0,0),(1,1)\] unity square
- returns the number of points inside the disk quarter

``` python
def estimate_nbr_points_in_quarter_circle(nbr_estimates):
    ...
    return nbr_trials_in_quarter_unit_circle
```

### 3. Make it distributed

- Wraps the previous function in \`\`\`python import dask.bag as db

  def calculate_pi_distributed(nnodes,nbr_samples_in_total) … return estimated_pi \`\`\`

- `nnodes` will use only `nnodes` partitions for bag and split the number of estimates for each worker nodes into `nnodes` blocks.

- Try it on `1e8` samples and benchmark it on 1 to 8 nodes. (use [`time`](https://docs.python.org/3/library/time.html#time.time))

- Plot the performance gain over one node and comment the plot.

See [Dask Bag documentation](https://docs.dask.org/en/stable/bag.html).

\Longrightarrow We see a near perfect linear scalability.

## Reuse

[CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)
