# Dask `delayed` App

Author

Affiliations

François-David Collin [](mailto:francois-david.collin@umontpellier.fr)

CNRS

IMAG

Paul-Valéry Montpellier 3 University

![Dask logo\\](https://docs.dask.org/en/latest/_images/dask_horizontal.svg)

# dask.delayed - parallelize any code

What if you don’t have an array or dataframe? Instead of having blocks where the function is applied to each block, you can decorate functions with `@delayed` and *have the functions themselves be lazy*.

This is a simple way to use `dask` to parallelize existing codebases or build [complex systems](https://blog.dask.org/2018/02/09/credit-models-with-dask).

**Related Documentation**

- [Delayed documentation](https://docs.dask.org/en/latest/delayed.html)
- [Delayed screencast](https://www.youtube.com/watch?v=SHqFmynRxVU)
- [Delayed API](https://docs.dask.org/en/latest/delayed-api.html)
- [Delayed examples](https://examples.dask.org/delayed.html)
- [Delayed best practices](https://docs.dask.org/en/latest/delayed-best-practices.html)

As we’ll see in the [distributed scheduler notebook](05_distributed.ipynb), Dask has several ways of executing code in parallel. We’ll use the distributed scheduler by creating a `dask.distributed.Client`. For now, this will provide us with some nice diagnostics. We’ll talk about schedulers in depth later.

### Iniatilization of the ipyparallel/dask interface

Code

``` python
from dask.distributed import LocalCluster
cluster = LocalCluster(n_workers=8, threads_per_worker=1)          # Fully-featured local Dask cluster
client = cluster.get_client()
client
```

    /Users/fradav/Documents/Dev/Python/Cours-programmation-MIASHS-2025/.venv/lib/python3.13/site-packages/distributed/node.py:187: UserWarning:

    Port 8787 is already in use.
    Perhaps you already have a cluster running?
    Hosting the HTTP server on port 50320 instead

### Client

Client-d03b346c-8a04-11f0-8eb6-33fba1d96b19

|  |  |
|:---|:---|
| **Connection method:** Cluster object | **Cluster type:** distributed.LocalCluster |
| **Dashboard:** [http://127.0.0.1:50320/status](http://127.0.0.1:50320/status) |  |

### Cluster Info

### LocalCluster

bdf22519

|  |  |
|:---|:---|
| **Dashboard:** [http://127.0.0.1:50320/status](http://127.0.0.1:50320/status) | **Workers:** 8 |
| **Total threads:** 8 | **Total memory:** 64.00 GiB |
| **Status:** running | **Using processes:** True |

### Scheduler Info

### Scheduler

Scheduler-0011c5dc-aba7-4bc5-92e3-c9c6a45b3f62

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:50321 | **Workers:** 0 |
| **Dashboard:** [http://127.0.0.1:50320/status](http://127.0.0.1:50320/status) | **Total threads:** 0 |
| **Started:** Just now | **Total memory:** 0 B |

### Workers

#### Worker: 0

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:50340 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:50343/status](http://127.0.0.1:50343/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:50324 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-k8zhrygj |  |

#### Worker: 1

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:50341 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:50342/status](http://127.0.0.1:50342/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:50326 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-d8scm0vj |  |

#### Worker: 2

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:50344 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:50349/status](http://127.0.0.1:50349/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:50328 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-uxoj7ewa |  |

#### Worker: 3

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:50347 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:50351/status](http://127.0.0.1:50351/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:50330 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-troz6kzd |  |

#### Worker: 4

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:50348 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:50354/status](http://127.0.0.1:50354/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:50332 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-czi3v5xe |  |

#### Worker: 5

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:50353 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:50357/status](http://127.0.0.1:50357/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:50334 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-daaxpmnp |  |

#### Worker: 6

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:50356 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:50360/status](http://127.0.0.1:50360/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:50336 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-4fxsa9xj |  |

#### Worker: 7

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:50359 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:50362/status](http://127.0.0.1:50362/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:50338 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-hwvg5152 |  |

## A Typical Workflow

Typically if a workflow contains a for-loop it can benefit from delayed. The following example outlines a read-transform-write:

``` python
import dask
    
@dask.delayed
def process_file(filename):
    data = read_a_file(filename)
    data = do_a_transformation(data)
    destination = f"results/{filename}"
    write_out_data(data, destination)
    return destination

results = []
for filename in filenames:
    results.append(process_file(filename))
    
dask.compute(results)
```

## Basics

First let’s make some toy functions, `inc` and `add`, that sleep for a while to simulate work. We’ll then time running these functions normally.

In the next section we’ll parallelize this code.

Code

``` python
from time import sleep


def inc(x):
    sleep(1)
    return x + 1


def add(x, y):
    sleep(1)
    return x + y
```

We time the execution of this normal code using the `%%time` magic, which is a special function of the Jupyter Notebook.

Code

``` python
%%time
# This takes three seconds to run because we call each
# function sequentially, one after the other

x = inc(1)
y = inc(2)
z = add(x, y) 
```

    CPU times: user 109 ms, sys: 73.4 ms, total: 183 ms
    Wall time: 3.01 s

### Parallelize with the `dask.delayed` decorator

Those two increment calls *could* be called in parallel, because they are totally independent of one-another.

We’ll make the `inc` and `add` functions lazy using the `dask.delayed` decorator. When we call the delayed version by passing the arguments, exactly as before, the original function isn’t actually called yet - which is why the cell execution finishes very quickly. Instead, a *delayed object* is made, which keeps track of the function to call and the arguments to pass to it.

Code

``` python
import dask


@dask.delayed
def inc(x):
    sleep(1)
    return x + 1


@dask.delayed
def add(x, y):
    sleep(1)
    return x + y
```

Code

``` python
%%time
# This runs immediately, all it does is build a graph

x = inc(1)
y = inc(2)
z = add(x, y)
```

    CPU times: user 247 μs, sys: 75 μs, total: 322 μs
    Wall time: 310 μs

This ran immediately, since nothing has really happened yet.

To get the result, call `compute`. Notice that this runs faster than the original code.

Code

``` python
%%time
# This actually runs our computation using a local thread pool

z.compute()
```

    CPU times: user 79.2 ms, sys: 48.7 ms, total: 128 ms
    Wall time: 2.02 s

    5

## What just happened?

The `z` object is a lazy `Delayed` object. This object holds everything we need to compute the final result, including references to all of the functions that are required and their inputs and relationship to one-another. We can evaluate the result with `.compute()` as above or we can visualize the task graph for this value with `.visualize()`.

Code

``` python
z
```

    Delayed('add-418d1996-7b3c-44d3-9430-80dbb55fa5e4')

Code

``` python
# Look at the task graph for `z`
z.visualize()
```

![](05_1_Dask_delayed_files/figure-html/cell-9-output-1.png)

Notice that this includes the names of the functions from before, and the logical flow of the outputs of the `inc` functions to the inputs of `add`.

### Some questions to consider:

- Why did we go from 3s to 2s? Why weren’t we able to parallelize down to 1s?
- What would have happened if the inc and add functions didn’t include the `sleep(1)`? Would Dask still be able to speed up this code?
- What if we have multiple outputs or also want to get access to x or y?

## Exercise: Parallelize a for loop

`for` loops are one of the most common things that we want to parallelize. Use `dask.delayed` on `inc` and `sum` to parallelize the computation below:

Code

``` python
data = [1, 2, 3, 4, 5, 6, 7, 8] 
```

Code

``` python
%%time
# Sequential code


def inc(x):
    sleep(1)
    return x + 1


results = []
for x in data:
    y = inc(x)
    results.append(y)

total = sum(results)
```

    CPU times: user 303 ms, sys: 199 ms, total: 501 ms
    Wall time: 8.03 s

Code

``` python
total
```

    44

Code

``` python
%%time
# Your parallel code here...
```

    CPU times: user 2 μs, sys: 0 ns, total: 2 μs
    Wall time: 4.05 μs

How do the graph visualizations compare with the given solution, compared to a version with the `sum` function used directly rather than wrapped with `delayed`? Can you explain the latter version? You might find the result of the following expression illuminating

``` python
inc(1) + inc(2)
```

## Putting it all together with a the producer-consumer pattern

## Introduction with a simple producer-consumer example

We’ll try to reproduce the producer/consumer code from asynchronous application with `asyncio` or `threading` but with `dask.delayed` and compute

``` python
from dask import delayed, compute
from dask.distributed import Queue, print
from time import sleep

queue = Queue()
...
```

## Exercise: Parallelize a for-loop code with control flow

Often we want to delay only *some* functions, running a few of them immediately. This is especially helpful when those functions are fast and help us to determine what other slower functions we should call. This decision, to delay or not to delay, is usually where we need to be thoughtful when using `dask.delayed`.

In the example below we iterate through a list of inputs. If that input is even then we want to call `inc`. If the input is odd then we want to call `double`. This `is_even` decision to call `inc` or `double` has to be made immediately (not lazily) in order for our graph-building Python code to proceed.

Code

``` python
def double(x):
    sleep(1)
    return 2 * x

def inc(x):
    sleep(1)
    return x + 1

def is_even(x):
    return not x % 2


data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
```

Code

``` python
%%time
# Sequential code

results = []
for x in data:
    if is_even(x):
        y = double(x)
    else:
        y = inc(x)
    results.append(y)

total = sum(results)
print(total)
```

    90
    CPU times: user 384 ms, sys: 273 ms, total: 657 ms
    Wall time: 10 s

``` python
%%time
# Your parallel code here...
# TODO: parallelize the sequential code above using dask.delayed
# You will need to delay some functions, but not all
```

### Some questions to consider:

- What are other examples of control flow where we can’t use delayed?

- What would have happened if we had delayed the evaluation of `is_even(x)` in the example above?

- What are your thoughts on delaying `sum`? This function is both computational but also fast to run.

- Example of control flow with we can’t use delayed : conditional loops, recursive functions

- Nothing, we have to compute it immediately for branching

- Delaying sum isn’t worth the graph walk overload

## Exercise: Parallelize a Pandas Groupby Reduction

In this exercise we read several CSV files and perform a groupby operation in parallel. We are given sequential code to do this and parallelize it with `dask.delayed`.

The computation we will parallelize is to compute the mean departure delay per airport from some historical flight data. We will do this by using `dask.delayed` together with `pandas`. In a future section we will do this same exercise with `dask.dataframe`.

## Create data

Run this code to prep some data.

This downloads and extracts some historical flight data for flights out of NYC between 1990 and 2000. The data is originally from [here](http://stat-computing.org/dataexpo/2009/the-data.html).

Code

``` python
import os
import requests

os.makedirs("data", exist_ok=True)
code_url = "https://raw.githubusercontent.com/dask/dask-tutorial/main/prep.py"
with open("prep.py", "wb") as f:
    f.write(requests.get(code_url).content)
%run prep.py -d flights
```

### Inspect data

Code

``` python
sorted(os.listdir(os.path.join("data", "nycflights")))
```

    ['1990.csv',
     '1991.csv',
     '1992.csv',
     '1993.csv',
     '1994.csv',
     '1995.csv',
     '1996.csv',
     '1997.csv',
     '1998.csv',
     '1999.csv']

### Read one file with `pandas.read_csv` and compute mean departure delay

Code

``` python
import pandas as pd

df = pd.read_csv(os.path.join("data", "nycflights", "1990.csv"))
df.head()
```

|  | Year | Month | DayofMonth | DayOfWeek | DepTime | CRSDepTime | ArrTime | CRSArrTime | UniqueCarrier | FlightNum | ... | AirTime | ArrDelay | DepDelay | Origin | Dest | Distance | TaxiIn | TaxiOut | Cancelled | Diverted |
|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|
| 0 | 1990 | 1 | 1 | 1 | 1621.0 | 1540 | 1747.0 | 1701 | US | 33 | ... | NaN | 46.0 | 41.0 | EWR | PIT | 319.0 | NaN | NaN | 0 | 0 |
| 1 | 1990 | 1 | 2 | 2 | 1547.0 | 1540 | 1700.0 | 1701 | US | 33 | ... | NaN | -1.0 | 7.0 | EWR | PIT | 319.0 | NaN | NaN | 0 | 0 |
| 2 | 1990 | 1 | 3 | 3 | 1546.0 | 1540 | 1710.0 | 1701 | US | 33 | ... | NaN | 9.0 | 6.0 | EWR | PIT | 319.0 | NaN | NaN | 0 | 0 |
| 3 | 1990 | 1 | 4 | 4 | 1542.0 | 1540 | 1710.0 | 1701 | US | 33 | ... | NaN | 9.0 | 2.0 | EWR | PIT | 319.0 | NaN | NaN | 0 | 0 |
| 4 | 1990 | 1 | 5 | 5 | 1549.0 | 1540 | 1706.0 | 1701 | US | 33 | ... | NaN | 5.0 | 9.0 | EWR | PIT | 319.0 | NaN | NaN | 0 | 0 |

5 rows × 23 columns

Code

``` python
# What is the schema?
df.dtypes
```

    Year                   int64
    Month                  int64
    DayofMonth             int64
    DayOfWeek              int64
    DepTime              float64
    CRSDepTime             int64
    ArrTime              float64
    CRSArrTime             int64
    UniqueCarrier         object
    FlightNum              int64
    TailNum              float64
    ActualElapsedTime    float64
    CRSElapsedTime         int64
    AirTime              float64
    ArrDelay             float64
    DepDelay             float64
    Origin                object
    Dest                  object
    Distance             float64
    TaxiIn               float64
    TaxiOut              float64
    Cancelled              int64
    Diverted               int64
    dtype: object

Code

``` python
# What originating airports are in the data?
df.Origin.unique()
```

    array(['EWR', 'LGA', 'JFK'], dtype=object)

Code

``` python
# Mean departure delay per-airport for one year
df.groupby("Origin").DepDelay.mean()
```

    Origin
    EWR     9.168411
    JFK    11.857274
    LGA     8.560045
    Name: DepDelay, dtype: float64

### Sequential code: Mean Departure Delay Per Airport

The above cell computes the mean departure delay per-airport for one year. Here we expand that to all years using a sequential for loop.

Code

``` python
from glob import glob

filenames = sorted(glob(os.path.join("data", "nycflights", "*.csv")))
```

Code

``` python
filenames
```

    ['data/nycflights/1990.csv',
     'data/nycflights/1991.csv',
     'data/nycflights/1992.csv',
     'data/nycflights/1993.csv',
     'data/nycflights/1994.csv',
     'data/nycflights/1995.csv',
     'data/nycflights/1996.csv',
     'data/nycflights/1997.csv',
     'data/nycflights/1998.csv',
     'data/nycflights/1999.csv']

Code

``` python
%%time

sums = []
counts = []
for fn in filenames:
    # Read in file
    df = pd.read_csv(fn)

    # Groupby origin airport
    by_origin = df.groupby("Origin")

    # Sum of all departure delays by origin
    total = by_origin.DepDelay.sum()

    # Number of flights by origin
    count = by_origin.DepDelay.count()

    # Save the intermediates
    sums.append(total)
    counts.append(count)

# Combine intermediates to get total mean-delay-per-origin
total_delays = sum(sums)
n_flights = sum(counts)
mean = total_delays / n_flights
```

    CPU times: user 1.1 s, sys: 200 ms, total: 1.3 s
    Wall time: 1.28 s

Code

``` python
mean
```

    Origin
    EWR    10.295469
    JFK    10.351299
    LGA     7.431142
    Name: DepDelay, dtype: float64

### Parallelize the code above

Use `dask.delayed` to parallelize the code above. Some extra things you will need to know.

1.  Methods and attribute access on delayed objects work automatically, so if you have a delayed object you can perform normal arithmetic, slicing, and method calls on it and it will produce the correct delayed calls.

2.  Calling the `.compute()` method works well when you have a single output. When you have multiple outputs you might want to use the `dask.compute` function. This way Dask can share the intermediate values.

So your goal is to parallelize the code above (which has been copied below) using `dask.delayed`. You may also want to visualize a bit of the computation to see if you’re doing it correctly.

``` python
%%time
# your code here
```

Code

``` python
# ensure the results still match
mean
```

    Origin
    EWR    10.295469
    JFK    10.351299
    LGA     7.431142
    Name: DepDelay, dtype: float64

### Some questions to consider:

- How much speedup did you get? Is this how much speedup you’d expect?
- Experiment with where to call `compute`. What happens when you call it on `sums` and `counts`? What happens if you wait and call it on `mean`?
- Experiment with delaying the call to `sum`. What does the graph look like if `sum` is delayed? What does the graph look like if it isn’t?
- Can you think of any reason why you’d want to do the reduction one way over the other?

### Learn More

Visit the [Delayed documentation](https://docs.dask.org/en/latest/delayed.html). In particular, this [delayed screencast](https://www.youtube.com/watch?v=SHqFmynRxVU) will reinforce the concepts you learned here and the [delayed best practices](https://docs.dask.org/en/latest/delayed-best-practices.html) document collects advice on using `dask.delayed` well.

Some improvements by actual parallelization of file reading, but we’re limited by IO throughput.

*Solution*. Delaying the sum could be interesting in case to make more balanced loads between tasks.

## Close the Client

Before moving on to the next exercise, make sure to close your client or stop this kernel.

Code

``` python
client.close()
```

## Reuse

[CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)
