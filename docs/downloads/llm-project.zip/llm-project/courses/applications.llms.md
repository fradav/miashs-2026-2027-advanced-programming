# Appendix B — Applications

Author

Affiliations

François-David Collin [](mailto:francois-david.collin@umontpellier.fr)

CNRS

IMAG

Paul-Valéry Montpellier 3 University

| Original (In Percent Format) | Online Html (Corrected) | Notebook (Corrected) |
|----|----|----|
| [Prompt engineering exercises](docs-resources/Notebooks/Courses/Applications/01_0_Code-Assistant-prompt-engineering.py) | [Solution](docs-resources/Notebooks/Courses/Solutions/01_0_Code-Assistant-prompt-engineering-sol.llms.md) | [Notebook](docs-resources/Notebooks/Courses/Solutions/01_0_Code-Assistant-prompt-engineering-sol.ipynb) |
| [AI Agent](docs-resources/Notebooks/Courses/Applications/01_1_AI-Agent.py) | [Solution](docs-resources/Notebooks/Courses/Solutions/01_1_AI-Agent-sol.llms.md) | [Notebook](docs-resources/Notebooks/Courses/Solutions/01_1_AI-Agent-sol.ipynb) |
| [Numpy Workout](docs-resources/Notebooks/Courses/Applications/02_0_Numpy_Workout.py) | [Solution](docs-resources/Notebooks/Courses/Solutions/02_0_Numpy_Workout-sol.llms.md) | [Notebook](docs-resources/Notebooks/Courses/Solutions/02_0_Numpy_Workout-sol.ipynb) |
| [Decorators Tutorial](docs-resources/Notebooks/Courses/Applications/02_1_Decorators_tutorial.py) | [Solution](docs-resources/Notebooks/Courses/Solutions/02_1_Decorators_tutorial-sol.llms.md) | [Notebook](docs-resources/Notebooks/Courses/Solutions/02_1_Decorators_tutorial-sol.ipynb) |
| [A tutorial on Python generators](docs-resources/Notebooks/Courses/Applications/02_2_Generators_tutorial.py) | [Solution](docs-resources/Notebooks/Courses/Solutions/02_2_Generators_tutorial-sol.llms.md) | [Notebook](docs-resources/Notebooks/Courses/Solutions/02_2_Generators_tutorial-sol.ipynb) |
| [Multiprocessing in Python 3](docs-resources/Notebooks/Courses/Applications/02_3_MultiProcessing_tutorial.py) | [Solution](docs-resources/Notebooks/Courses/Solutions/02_3_MultiProcessing_tutorial-sol.llms.md) | [Notebook](docs-resources/Notebooks/Courses/Solutions/02_3_MultiProcessing_tutorial-sol.ipynb) |
| [Scaling App with multiprocessing](docs-resources/Notebooks/Courses/Applications/02_4_Scaling.py) | [Solution](docs-resources/Notebooks/Courses/Solutions/02_4_Scaling-sol.llms.md) | [Notebook](docs-resources/Notebooks/Courses/Solutions/02_4_Scaling-sol.ipynb) |
| [An asyncio application](docs-resources/Notebooks/Courses/Applications/03_0_Asynchronous.py) | [Solution](docs-resources/Notebooks/Courses/Solutions/03_0_Asynchronous-sol.llms.md) | [Notebook](docs-resources/Notebooks/Courses/Solutions/03_0_Asynchronous-sol.ipynb) |
| [IPC and Locking](docs-resources/Notebooks/Courses/Applications/04_0_IPC_and_Locking.py) | [Solution](docs-resources/Notebooks/Courses/Solutions/04_0_IPC_and_Locking-sol.llms.md) | [Notebook](docs-resources/Notebooks/Courses/Solutions/04_0_IPC_and_Locking-sol.ipynb) |
| [Locking with multiprocessing.Value](docs-resources/Notebooks/Courses/Applications/04_1_IPC_and_Locking_cont.py) | [Solution](docs-resources/Notebooks/Courses/Solutions/04_1_IPC_and_Locking_cont-sol.llms.md) | [Notebook](docs-resources/Notebooks/Courses/Solutions/04_1_IPC_and_Locking_cont-sol.ipynb) |
| [Distributed models examples](docs-resources/Notebooks/Courses/Applications/05_0_Distributed_models.py) | [Solution](docs-resources/Notebooks/Courses/Solutions/05_0_Distributed_models-sol.llms.md) | [Notebook](docs-resources/Notebooks/Courses/Solutions/05_0_Distributed_models-sol.ipynb) |
| [Dask delayed App](docs-resources/Notebooks/Courses/Applications/05_1_Dask_delayed.py) | [Solution](docs-resources/Notebooks/Courses/Solutions/05_1_Dask_delayed-sol.llms.md) | [Notebook](docs-resources/Notebooks/Courses/Solutions/05_1_Dask_delayed-sol.ipynb) |
| [Numba Introduction](docs-resources/Notebooks/Courses/Applications/06_0_Numba_tutorial.py) | [Solution](docs-resources/Notebooks/Courses/Solutions/06_0_Numba_tutorial-sol.llms.md) | [Notebook](docs-resources/Notebooks/Courses/Solutions/06_0_Numba_tutorial-sol.ipynb) |
| [Numba first steps](docs-resources/Notebooks/Courses/Applications/06_1_Numba.py) | [Solution](docs-resources/Notebooks/Courses/Solutions/06_1_Numba-sol.llms.md) | [Notebook](docs-resources/Notebooks/Courses/Solutions/06_1_Numba-sol.ipynb) |
