# Appendix C — Slides in reveal.js

Author

Affiliations

François-David Collin [](mailto:francois-david.collin@umontpellier.fr)

CNRS

IMAG

Paul-Valéry Montpellier 3 University

- [Code Assistants](docs-resources/Slides/Courses/01_Code-Assistant.revealjs.llms.md)

- [Numpy Workout](docs-resources/Slides/Courses/Applications/02_0_Numpy_Workout.revealjs.llms.md)

- [Introduction to parallel computing](docs-resources/Slides/Courses/02_Parallel-intro.revealjs.llms.md)

- [Asynchronous Programming with Python](docs-resources/Slides/Courses/03_Asynchronous.revealjs.llms.md)

- [IPC and locking](docs-resources/Slides/Courses/04_IPC-and-Locking.revealjs.llms.md)

- [Distributed Computing models](docs-resources/Slides/Courses/05_Distributed.revealjs.llms.md)

- [Dask and Ray](docs-resources/Slides/Courses/06_Dask-Ray.revealjs.llms.md)

- [Dask delayed](docs-resources/Slides/Courses/07_Dask-delayed.revealjs.llms.md)

- [Hardware Vectorization with SIMD](docs-resources/Slides/Courses/08_SIMD.revealjs.llms.md)

- [GPU computing, CPU cache, Computing cluster](docs-resources/Slides/Courses/09_GPU-Caching-etc.revealjs.llms.md)

- [Your First WebGPU App](docs-resources/Slides/Courses/10_WebGPU-First-App.revealjs.llms.md)

- [Designing parallel algorithms](docs-resources/Slides/Courses/11_0_Designing-parallel.revealjs.llms.md)
