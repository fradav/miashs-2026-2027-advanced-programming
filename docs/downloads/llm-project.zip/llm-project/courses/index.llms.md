# Advanced programming and parallel computing

Author

Affiliations

François-David Collin [](mailto:francois-david.collin@umontpellier.fr)

CNRS

IMAG

Paul-Valéry Montpellier 3 University

Published

Wednesday, August 27, 2025

# Preface

This is the course and materials for the lecture on “Advanced programming and parallel computing” at the Paul Valery University of Montpellier, France.
