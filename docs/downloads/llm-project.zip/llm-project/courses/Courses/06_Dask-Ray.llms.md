# 7  Dask and Ray

A deep dive into cluster parallel computing

Author

Affiliations

François-David Collin [](mailto:francois-david.collin@umontpellier.fr)

CNRS

IMAG

Paul-Valéry Montpellier 3 University

# 8 Dask vs. Ray: Programming Paradigm Comparison

Here’s a structured outline for your lecture comparing Dask and Ray from a programming paradigm perspective

## 8.1 ![](../images/dask_icon.svg) Dask

- **Dask** is a flexible parallel computing library for analytics.
- Integrates seamlessly with NumPy, Pandas, and Scikit-learn.
- Uses a **task graph paradigm** to break down computations into smaller tasks.
- Enables parallel execution of tasks for scalable analytics.

![](d2-figures/dask-overview.svg)

## 8.2 ![](../images/ray-logo.svg)

- **Ray** is a distributed execution framework for building and running distributed applications.
- Supports a wide range of workloads, including machine learning and reinforcement learning.
- Uses an **actor model paradigm** for stateful computations.
- Allows dynamic task scheduling and fine-grained control over distributed execution.

![](../images/map-of-ray.svg)

## 8.3 Dask: Task Graph Computing

``` python
import numpy as np
import dask.array as da

data = np.arange(100_000).reshape(200, 500)
a = da.from_array(data, chunks=(100, 100))
a
```

[TABLE]

``` python
mean_graph = a.mean()
mean_graph.visualize()
```

![](06_Dask-Ray_files/figure-revealjs/cell-3-output-1.png)

``` python
result = mean_graph.compute()
result
```

    np.float64(49999.5)

## 8.4 Ray’s actor model example

``` python
import ray

@ray.remote
class Counter:
    def __init__(self):
        self.value = 0

    def increment(self):
        self.value += 1
        return self.value

# Create actor instances
counters = [Counter.remote() for _ in range(4)]
# Increment counters in parallel
ray.get([counter.increment.remote() for counter in counters])
```

    [1, 1, 1, 1]

## 8.5 Key Differences Dask vs Ray

| Feature    | Dask                        | Ray                        |
|------------|-----------------------------|----------------------------|
| Paradigm   | Task graph (functional)     | Actor model (OOP)          |
| State      | Stateless (pure functions)  | Stateful (actor instances) |
| Scheduling | Static graph optimization   | Dynamic task scheduling    |
| Best for   | Array/collection operations | Heterogeneous workloads    |

## 8.6 Practical Examples

``` python
# Dask version (graph-based)
import dask.bag as db

bag = db.read_text('large_file.txt')
result = bag.map(lambda x: x.upper()).compute()
```

``` python
# Ray version (actor-based)
@ray.remote
def process_line(line):
    return line.upper()

with open('large_file.txt') as f:
    lines = f.readlines()

results = ray.get([process_line.remote(line) for line in lines])
```

## 8.7 Example 2: Machine Learning

``` python
# Dask-ML example
from dask_ml.linear_model import LogisticRegression
from dask_ml.datasets import make_classification

X, y = make_classification(n_samples=100000, chunks=1000)
clf = LogisticRegression()
clf.fit(X, y)
```

``` python
# Ray Train example
from ray.train.xgboost import XGBoostTrainer

trainer = XGBoostTrainer(
    label_column="target",
    params={"objective": "binary:logistic"},
    datasets={"train": ray.data.from_pandas(df)},
)
result = trainer.fit()
```

## 8.8 Performance Considerations

Dask excels at:

- Large array operations
- Predictable workloads
- Numpy/Pandas-like workflows

Ray excels at:

- Heterogeneous tasks
- Stateful applications
- Reinforcement learning

## 8.9 Hybrid Approaches

``` python
# Using both together
import dask.dataframe as dd
import ray

# Process data with Dask
ddf = dd.read_csv('large_dataset.csv')
processed = ddf.groupby('category').mean()

# Use Ray for model serving
@ray.remote
class ModelServer:
    def __init__(self, model):
        self.model = model
    def predict(self, data):
        return self.model.predict(data)

# Convert Dask results to Ray tasks
model = train_model(processed.compute())
servers = [ModelServer.remote(model) for _ in range(4)]
```

# 9 Conclusion

**Choose Dask if:**

- Your workload is similar to NumPy/Pandas
- You need lazy evaluation
- You’re doing numerical computing

**Choose Ray if:**

- You need stateful actors or dynamic task scheduling
- Your workload is heterogeneous
- You’re building microservices
