# 3  Introduction to parallel computing

A very general (and generic) introduction

Authors

Affiliations

François-David Collin [](mailto:francois-david.collin@umontpellier.fr)

CNRS

IMAG

Paul-Valéry Montpellier 3 University

Ghislain Durif [](mailto:ghislain.durif@ens-lyon.fr)

CNRS

LBMC

# 4 Parallel computing: the intuition

## 4.1 Computing ?

- a **computation** = a succession of **tasks** to complete
- a **task** \approx a single command/action or a group of commands/actions

Example 1:

Example 2:

``` python
# task i:
# sum of elements at index i
# from two vectors
for i in range(10):
    res[i] = a[i] + b[i]
```

``` python
# task 1: matrix product
C = A @ B
# task 2: colwise sum over matrix C
np.sum(C,axis=0)
```

## 4.2 Why parallel computing?

- **Objective:** accelerate computations \<=\> reduce computation time

- **Idea:** run multiple tasks in parallel instead of sequentially

## 4.3 Context (level 1)

- different **tasks** to complete

- one or more **workers** to complete the tasks

## 4.4 Sequential computing

- n tasks to complete (n\>1)
- 1 worker

**Total time** (exercise)

\sum\_{i=1}^n t_i \sim O(n)\\ with t_i time to complete task i}

![](d2-figures/sequential-computing.svg)

## 4.5 Parallel computing (the most simple case)

![](d2-figures/parallel-computing-simple.svg)

- n tasks to complete (n\>1)
- p workers (p\>=n)

**Total time** (exercise)

\underset{i=1,\dots,n}{\text{max}}\\t_i\\\sim O(1)\\ with t_i time to complete task i

**Potential bottleneck?** (exercise)

not enough workers to complete all tasks

## 4.6 Task scheduling

- n tasks to complete (n\>1)

- p workers (p\<n)

**Need:** assign multiple tasks to each worker (and manage this assignment)

![](d2-figures/parallel-computing-complex.svg)

**Total time** (exercise)

\underset{k=1,\dots,p}{\text{max}}\\T_k\\\sim O(n/p)\\ with T_k = \sum\_{i\in I_k} t_i, total time to complete all tasks assigned to worker k (where I_k is the set of indexes of tasks assigned to worker k)

## 4.7 Illustration: parallel computing (simple case)

- a task = “wait 1 \mus”

- Objective: run 100 tasks

- Number of workers: 1, 2, 4, 6, 8

**Why is the time gain not linear?**

![](figs/parallel1.jpg)

10 repetitions in each configurations

## 4.8 Context (level 2)

- different **tasks** to complete

- multiple **workers** to complete the tasks

- one or more **working resources**[^1]

**Potential bottleneck?** (exercise)

not enough resources for all workers

## 4.9 Resource management

- n tasks to complete (n\>1)
- p workers (p\<n)
- q working resources (q\<p)

**Need:**

- assign workers to each resource (and manage this assignment)

**Total time** = ? (exercise)

**Potential issues?** (exercise)

![](d2-figures/parallel-computing-ressources.svg)

## 4.10 Resource management

**Total time** = \text{max}\_{\ell=1,\dots,q}\\\tau\_\ell\\\sim O(n/q)

with \tau\_\ell = \sum\_{i\in J\_\ell} t_i = total time to complete all tasks done on resource \ell (where J\_\ell is the set of indexes of tasks assigned done on resource \ell)

**Potential issues?** multiple workers want to use the same working resources

- they have to wait for their turn (workers are not working all the time)
- risk to jam[^2] resource access (organizing resource access takes time)

## 4.11 Illustration: overhead for resource access

- a task = “wait 1 \mus”

- Objective: run 100 tasks

- 8 computing units

- Number of workers: 1, 2, 4, 8, 16, 32

![](figs/parallel2.jpg)

10 repetitions in each configurations

## 4.12 Context (level 3: realistic)

- different **tasks** to complete

- multiple **workers** to complete the tasks

- one or more **working resources**

**Input/Output (I/O)**

- **Input:** each task requires some **materials** (data) to be completed, these materials are stored in a storage area (memory)

- **Output:** each task returns a **result** that need to be put in the storage area (memory)

Examples: vector/matrix/array operations, process the content of multiple files

## 4.13 Input/Output management

- n tasks to complete (n\>1)
- p workers (p\<n)
- q working resources (q\<p)
- tasks need input (data) and produce output (results)

**Need:**

- load input (data) from storage when needed by a worker to complete a task
- write output (result) to storage when a task is completed

**Total time** = ? (exercise)

## 4.14 Parallel computing: realistic model

![](d2-figures/parallel-computing-real.svg)

## 4.15 Computing time and potential bottleneck

**Total time** = \text{max}\_{\ell=1,\dots,q}\\\tau\_\ell\\

with \tau\_\ell = \sum\_{i\in J\_\ell} t\_{i,\text{in}} + t_i + t\_{i,\text{out}} = total time to complete all tasks done on resource \ell (where J\_\ell is the set of indexes of tasks done on resource \ell)

**Potential bottlenecks:**

- input (data) are not ready/available when a worker need them to complete a task (the worker have to wait)
- output (results) cannot be written when a worker complete a task (the worker have to wait)

**Overhead on memory access**

- concurrent access to a memory space when reading input and/or when writing output
- concurrent data transfer from or to memory (the “pipe” are jammed)

## 4.16 Illustration 1: overhead for I/O access

- a task
  1.  simulate a vector of 10 values
  2.  compute the mean
- Objective: run 10000 tasks
- Resources: 8 computing units
- Number of workers: 1, 2, 4, 6, 8

![](figs/parallel3.jpg)

10 repetitions in each configurations

## 4.17 Illustration 2: overhead for I/O access

- a task = “compute the sum of a given row in a matrix”

- Objective: compute all row-wise sums for a 10000 \times 1000 matrix (i.e. 10000 tasks)

- Resources: 8 computing units

- Number of workers: 1, 2, 4, 6, 8

![](figs/parallel4.jpg)

20 repetitions in each configurations

## 4.18 The vocabulary of parallel computing

- tasks = a command or a group of commands
- worker = a program or a sub-program (*like a thread or a sub-process*) → *Software*
- working resources = processing units → *Hardware*
- input = data
- output = result
- storage = memory

**Attention:** “worker” may sometimes refer to a working resource in the literature

## 4.19 Task synchronization

Sometimes tasks cannot be done in parallel

- Specific case: output of task i_1 is input of task i_2
- **Need:** wait for task i_1 before task i_2 starts

Example 1:

``` python
# task 1: matrix product
C = A @ B
# task 2: colwise sum over matrix C
np.sum(C,axis=0)
```

Example 2:

- task 1: train a predictive model
- task 2: use the trained model to predict new labels

# 5 Why parallel computing

## 5.1 Trend over ~50years

- Moore’s Law (doubling the transistor counts every two years) is live
- Single thread performance hit a wall in 2000s
- Along with typical power usage and frequency
- Number of logical cores is doubling every ~3 years since mid-2000

![](50yearstrend/50-years-processor-trend.svg)

Original data up to the year 2010 collected and plotted by M. Horowitz, F. Labonte, O. Shacham, K. Olukotun, L. Hammond, and C. Batten New plot and data collected for 2010-2021 by K. Rupp

[Github repo for data](https://github.com/karlrupp/microprocessor-trend-data/tree/master/50yrs)

## 5.2 Computing units

- CPU :
  - 4/8/16+ execution cores (depending on context, laptop, desktop, server)
  - Hyperthreading (Intel) or SMT (AMD), x2
  - Vector units (multiple instructions processed on a vector of data)
- GPU computing : 100/1000 “simple” cores per card

## 5.3 The reality

![](figs/serial_waste.png)

A serial application only accesses 0.8% of the processing power of a 16-core CPU.

0.08\\ = \frac{1}{16 \* 2 (cores + hyperthreading) \* \frac{256 (bitwide vector unit}{64(bit double)} = 128}

# 6 Benefits of parallel computing

## 6.1 Faster for less development

\frac{S\_{up}}{T\_{par}} \gg \frac{S\_{up}}{T\_{seq}}

Ratio of speedup improvment S\_{up} over time of development (T\_{seq\|par}) comparison.

From a development time perspective, return on investment (speedup) is often *several magnitudes of order* better than pure “serial/sequential” improvment.

## 6.2 Scaling

Simple “divide and conquer” strategies in parallel programming allow to handle data with previously almost untractable sizes and scale before.

## 6.3 Energy efficiency

> **NOTE:**
>
> This is a huge one, in the present context 😬

Difficult to estimate but the *Thermal Design Power (TDP)*, given by hardware manufacturers, is a good rule of thumb. Just factor the number of units, and usual proportionality rules.

## 6.4 Energy efficiency, a bunch of CPUs

Example of “standard” use : 20 [16-core Intel Xeon E5-4660](https://ark.intel.com/content/www/us/en/ark/products/93796/intel-xeon-processor-e54660-v4-40m-cache-2-20-ghz.html) which is 120~W of TDP

P = (20~Processors) \* (120~W/~Processors) \* (24~hours) = 57.60~kWhrs

## 6.5 Energy efficiency, just a few (big) GPUs

A Tesla V100 GPU is of 300~W of TDP. Let’s use 4 of them.

P = (4~GPUs) \* (300~W/~GPUs) \* (24~hours) = 28.80~kWhrs

\Longrightarrow half of the power use

# 7 Laws

## 7.1 Terms and definitions

- **Speedup** S\_{up}(N): ratio of the time of execution in serial and parallel mode
- Number of computing units N
- P (resp. S) is the parallel (resp. serial) fraction of the time spent in the parallel (resp. serial) part of the program (P+S=1).

## 7.2 Asymptote of parallel computing : [Amdahl’s Law](https://en.wikipedia.org/wiki/Amdahl%27s_law)

There P is the fraction of the time spent in the parallel part of the program in *a sequential execution*.

S\_{up}(N) \le \frac{1}{S+\frac{P}{N}}

## 7.3 Asymptote of parallel computing : Amdahl’s Law, Graphic

![](./figs/amdhals.png)

Ideal speedup : 100% of the code parallelized; 90%, 75%, and 50% : limited by the fractions of code that remain serial. ([Robey and Zamora 2021](#ref-robey2021parallel))

## 7.4 More with (almost) less : the *pump it up* approach

[Gustafson’s law](https://en.wikipedia.org/wiki/Gustafson%27s_law)

There now, P is the fraction of the time spent in the parallel part of the program in *a parallel execution*.

![](figs/gimmemore-meme.png)

When the size of the problem grows up proportionnaly to the number of computing units.

S\_{up}(N) \le N - S\*(N-1)

where N is the number of computing units and *S* the serial fraction as before.

## 7.5 More with (almost) less : graphic

![](./figs/gustafsons.png)

Linear growth with the number of processor (and data size too)

## 7.6 Strong vs Weak Scaling, definitions

Strong Scaling  
Strong scaling represents the time to solution with respect to the number of processors for a fixed total size.

\Rightarrow Amdahl’s law

Weak Scaling  
Weak scaling represents the time to solution with respect to the number of processors for a fixed-sized problem per processor.

\Rightarrow Gustafson’s law

## 7.7 Strong vs Weak Scaling, schemas

![](d2-figures/strong-scaling.svg)

![](d2-figures/weak-scaling.svg)

# 8 Types of parallelism

## 8.1 Flynn’s taxonomy

|               | Simple Instruction | Multiple Instructions |
|---------------|--------------------|-----------------------|
| Simple Data   | ![](figs/SISD.svg) | ![](figs/MISD.svg)    |
| Multiple Data | ![](figs/SIMD.svg) | ![](figs/MIMD.svg)    |

## 8.2 A different approach

| Parallelism level | Hardware | Software | Parallelism extraction |
|----|----|----|----|
| Instruction | SIMD (or VLIW) | Intrinsics | Compiler |
| Thread | Multi-core RTOS | Library or language extension | Partitioning/Scheduling (dependency control) |
| Task | Multi-core (w/o RTOS) | Processes (OS level) | Partitioning/Scheduling |

## 8.3 Multi-processing vs Multi-threading

![](tikz-figures/multiprocessing_model.svg)

Multi-Processing

![](tikz-figures/multithreading_model.svg)

Multi-Threading

|                   | Multi-processing | Multi-threading  |
|-------------------|------------------|------------------|
| Memory            | Exclusive        | Shared           |
| Communication     | Inter-process    | At caller site   |
| Creation overhead | Heavy            | Minimal          |
| Concurrency       | At OS level      | Library/language |

# 9 Conclusion

- Parallelism is everywhere, but not always easy to exploit
- Two types of *scaling* with parallelism : strong and weak
- Several types of parallelism : Flynn’s taxonomy, multhreading vs multiprocessing etc.

# 10 References

Pelcat, Maxime. 2010. “Prototypage Rapide Et génération de Code Pour DSP Multi-Coeurs Appliqués à La Couche Physique Des Stations de Base 3GPP LTE.” PhD thesis, INSA de Rennes.

Robey, R., and Y. Zamora. 2021. *Parallel and High Performance Computing*. Manning. <https://www.manning.com/books/parallel-and-high-performance-computing>.

[^1]: i.e. a set of tools/machines used by a worker to complete a task

[^2]: overhead on resource access
