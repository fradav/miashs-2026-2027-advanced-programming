# 12  Designing parallel algorithms

A concrete example with matrix sum

Author

Affiliations

François-David Collin [](mailto:francois-david.collin@umontpellier.fr)

CNRS

IMAG

Paul-Valéry Montpellier 3 University

# 13 Designing parallel algorithms

## 13.1 Row/Column-wise matrix sum

- Matrix A = \[a\_{ij}\]\_{i=1:N}^{j=1:P} of dimension N \times P

\begin{bmatrix} \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ \\ \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ \\ \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & a\_{ij} & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\\\ \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ \\ \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ \\ \end{bmatrix}\_{N \times P}

- **Row-wise sum:** vector C = \[c\_{i}\]\_{i=1:N} of size N where c\_{i} = \sum\_{j=1}^P a\_{ij}

- **Column-wise sum:** vector D = \[d\_{j}\]\_{j=1:P} of size P where d\_{j} = \sum\_{i=1}^N a\_{ij}

## 13.2 Row-wise sum

\begin{bmatrix} \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ \\ \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ \\ \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & a\_{ij} & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\\\ \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ \\ \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ \\ \end{bmatrix}\_{N \times P}\\ \\ \rightarrow \\ \\ \begin{bmatrix} \vdots \\ \vdots \\ \sum\_{j=1}^{P} a\_{ij} \\ \vdots\\ \vdots\\ \end{bmatrix}\_{N \times 1}

## 13.3 Column-wise sum

\begin{array}{c} \begin{bmatrix} \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ \\ \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ \\ \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & a\_{ij} & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\\\ \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ \\ \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ & \\ \\ \\ \cdot \\ \\ \\ \\ \end{bmatrix}\_{N \times P}\\ \downarrow \\ \\ \\ \\ \\ \\ \\ \begin{bmatrix} \\ \dots \\ & \dots & \sum\_{i=1}^{N} a\_{ij} & \dots & \\ \dots \\ \\ \end{bmatrix}\_{1\times P}\\ \end{array}

## 13.4 Row/Column-wise matrix sum algorithm

Row-wise sum:

``` python
# input
matA = np.array(...).reshape(N,P)
# output
vecD = np.zeros(N)
# algorithm
for i in range(N):
  for j in range(P):
    vecD[i] += matA[i,j]
```

Column-wise sum:

``` python
# input
matA = np.array(...).reshape(N,P)
# output
vecD = np.zeros(P)
# algorithm
for j in range(P):
  for i in range(N):
    vecD[j] += matA[i,j]
```

**Exercise:** parallel algorithm?

Solution 1?

``` python
# input
matA = np.array(...).reshape(N,P)
# output
vecD = np.zeros(N)
# algorithm
@parallel
for i in range(N):
  for j in range(P):
    vecD[i] += matA[i,j]
```

Solution 2?

``` python
# input
matA = np.array(...).reshape(N,P)
# output
vecD = np.zeros(P)
# algorithm
@parallel
for j in range(P):
  for i in range(N):
    vecD[i] += matA[i,j]
```

**Exercise:** any concurrent access to memory by the parallel tasks ? in input (reading) ? in output (writing) ?

## 13.5 Concurrent access to memory

Solution 1:

- reading (input): no concurrent access
- writing (output): no concurrent access

Solution 2:

- reading (input): no concurrent access
- writing (output): what happen if tasks j_1 and j_2 need to simultaneously update `vecD[i]`?

\rightarrow need for *synchronization* (with a time cost)

Solution 3?

``` python
# input
matA = np.array(...).reshape(N,P)
# output
vecD = np.zeros(P)
# algorithm
for j in range(P):
  @parallel
  for i in range(N):
    vecD[i] += matA[i,j]
```

Solution 4?

``` python
# input
matA = np.array(...).reshape(N,P)
# output
vecD = np.zeros(N)
# algorithm
for i in range(N):
  @parallel
  for j in range(P):
    vecD[i] += matA[i,j]
```

(**Concurrent access** between tasks to update `vecD[i]`)

**Any other issue ?**

## 13.6 Cost of parallel task management

``` python
@parallel
for i in range(N):
  for j in range(P):
    ...
```

1 launch of N parallel tasks running each P operations

\rightarrow N “long” parallel tasks

Cost (in time) to launch parallel tasks \sim O(N)

``` python
for j in range(P):
  @parallel
  for i in range(N):
    ...
```

P launches of N parallel tasks running each 1 operation

\rightarrow N \times P “short” parallel tasks

Cost (in time) to launch parallel tasks \sim O(NP)

## 13.7 Parallel column-wise matrix sum algorithm

Solution 1?

``` python
# input
matA = np.array(...).reshape(N,P)
# output
vecD = np.zeros(P)
# algorithm
@parallel
for j in range(P):
  for i in range(N):
    vecD[j] += matA[i,j]
```

Solution 2?

``` python
# input
matA = np.array(...).reshape(N,P)
# output
vecD = np.zeros(P)
# algorithm
@parallel
for i in range(N):
  for j in range(P):
    vecD[j] += matA[i,j]
```

**Concurrent access** between tasks to update `vecD[j]`

## 13.8 Illustration: column/row-wise matrix sum algorithm

Parallel column-wise vs parallel row-wise matrix sum algorithms

- Matrix 10000 \times 10000

- Objective: run 10000 tasks

- Resources: 64 computing units

- Number of workers: 1, 2, 4, 8, 16, 32

**Exercise 1:** why the performance degradation?

{\rightarrow overhead for memory access}

**Exercise 2:** why the performance difference?

{\rightarrow impact of array storage order}

![](figs/row_col_sum.jpg)

20 repetitions in each configurations

## 13.9 Array storage order

Matrix in memory = a big array of contiguous rows or columns

### 13.9.1 Row-major

Memory: \begin{array}{\|c\|c\|c\|} \hline a\_{11} & a\_{12} & a\_{13} \\ \hline \end{array}\\ \begin{array}{\|c\|c\|c\|} \hline a\_{21} & a\_{22} & a\_{23} \\ \hline \end{array}\\ \begin{array}{\|c\|c\|c\|} \hline a\_{31} & a\_{32} & a\_{33} \\ \hline \end{array}

### 13.9.2 Column-major

Memory: \begin{array}{\|c\|c\|c\|} \hline a\_{11} & a\_{21} & a\_{31} \\ \hline \end{array}\\ \begin{array}{\|c\|c\|c\|} \hline a\_{12} & a\_{22} & a\_{32} \\ \hline \end{array}\\ \begin{array}{\|c\|c\|c\|} \hline a\_{13} & a\_{23} & a\_{33} \\ \hline \end{array}

![](figs/row_and_column_major_order.png)

Source: `wikimedia.org`

## 13.10 Accessing array elements in memory

Memory access: **read data from memory by block**

To access a\_{11}: load \begin{array}{\|c\|c\|c\|} \hline a\_{11} & a\_{12} & a\_{13} \\ \hline \end{array} into cache

To access a\_{11}: load \begin{array}{\|c\|c\|c\|} \hline a\_{11} & a\_{21} & a\_{31} \\ \hline \end{array} into cache

![](figs/row_and_column_major_order.png)

Source: `wikimedia.org`

## 13.11 Row-major order and row-wise sum

To compute a\_{11} + a\_{12} + a\_{13} ?

1.  init `res` =0
2.  load \begin{array}{\|c\|c\|c\|} \hline a\_{11} & a\_{12} & a\_{13} \\ \hline \end{array} into cache
3.  compute `res` = `res` + a\_{11}
4.  compute `res` = `res` + a\_{12}
5.  compute `res` = `res` + a\_{13}

![](figs/row_and_column_major_order.png)

Source: `wikimedia.org`

## 13.12 Column-major order and row-wise sum

To compute a\_{11} + a\_{12} + a\_{13} ?

1.  init `res` =0
2.  load \begin{array}{\|c\|c\|c\|} \hline a\_{11} & a\_{21} & a\_{31} \\ \hline \end{array} into cache
3.  compute `res` = `res` + a\_{11}
4.  load \begin{array}{\|c\|c\|c\|} \hline a\_{12} & a\_{22} & a\_{32} \\ \hline \end{array} into cache
5.  compute `res` = `res` + a\_{12}
6.  load \begin{array}{\|c\|c\|c\|} \hline a\_{13} & a\_{23} & a\_{33} \\ \hline \end{array} into cache
7.  compute `res` = `res` + a\_{13} More memory accesses \rightarrow time consuming

![](figs/row_and_column_major_order.png)

Source: `wikimedia.org`

## 13.13 Memory access to large data

Example: **“big” matrix** (4 \times 6) \tiny \begin{array}{\|c\|c\|c\|c\|c\|c\|c\|}\hline a\_{11} & a\_{12} & a\_{13} & a\_{14} & a\_{15} & a\_{16} \\ \hline a\_{21} & a\_{22} & a\_{23} & a\_{24} & a\_{25} & a\_{26} \\ \hline a\_{31} & a\_{32} & a\_{33} & a\_{34} & a\_{35} & a\_{36} \\ \hline a\_{41} & a\_{42} & a\_{43} & a\_{44} & a\_{45} & a\_{46} \\ \hline\end{array}

Storage in memory (row major):

\tiny \begin{array}{\|c\|c\|c\|c\|c\|c\|c\|} \hline a\_{11} & a\_{12} & a\_{13} & a\_{14} & a\_{15} & a\_{16} \\ \hline \end{array} \begin{array}{\|c\|c\|c\|c\|c\|c\|c\|} \hline a\_{21} & a\_{22} & a\_{23} & a\_{24} & a\_{25} & a\_{26} \\ \hline \end{array} \begin{array}{\|c\|c\|c\|c\|c\|c\|c\|} \hline a\_{31} & a\_{32} & a\_{33} & a\_{34} & a\_{35} & a\_{36} \\ \hline \end{array} \begin{array}{\|c\|c\|ccc} \hline a\_{41} & a\_{42} & \cdot & \cdot & \cdot \\ \hline \end{array}

Access by **sub-blocks**[^1] of data (e.g. sub-block of rows or columns)

- Example: load block \begin{array}{\|c\|c\|c\|} \hline a\_{11} & a\_{12} & a\_{13} \\ \hline \end{array} into cache to access a\_{11}

## 13.14 Impact of data dimension

Sum of row 1 (row major):

1.  access block \begin{array}{\|c\|c\|c\|} \hline a\_{11} & a\_{12} & a\_{13} \\ \hline \end{array} res = res + a\_{11} + a\_{12} + a\_{13}

2.  access block \begin{array}{\|c\|c\|c\|} \hline a\_{14} & a\_{15} & a\_{16} \\ \hline \end{array} res = res + a\_{14} + a\_{15} + a\_{16}

## 13.15 Impact of data dimension, II

Sum of row 1 (column major):

1.  access block \begin{array}{\|c\|c\|c\|} \hline a\_{11} & a\_{21} & a\_{31} \\ \hline \end{array} res = res + a\_{11}

2.  access block \begin{array}{\|c\|c\|c\|} \hline a\_{12} & a\_{22} & a\_{32} \\ \hline \end{array} res = res + a\_{12}

3.  access block \begin{array}{\|c\|c\|c\|} \hline a\_{13} & a\_{23} & a\_{33} \\ \hline \end{array} res = res + a\_{13}

4.  access block \begin{array}{\|c\|c\|c\|} \hline a\_{14} & a\_{24} & a\_{34} \\ \hline \end{array} res = res + a\_{14}

5.  access block \begin{array}{\|c\|c\|c\|} \hline a\_{15} & a\_{25} & a\_{35} \\ \hline \end{array} res = res + a\_{14}

6.  access block \begin{array}{\|c\|c\|c\|} \hline a\_{16} & a\_{26} & a\_{36} \\ \hline \end{array} res = res + a\_{16}

## 13.16 Matrix product

- Matrix A = \[a\_{ij}\]\_{i=1:N}^{j=1:P} of dimension N\times{}P

- Matrix B = \[b\_{jk}\]\_{j=1:P}^{k=1:Q} of dimension N\times{}P

- **Matrix product:** C = A \times B = \[c\_{ik}\]\_{i=1:N}^{k=1:Q} of dimension N\times{}Q where

c\_{ik} = \sum\_{j=1}^P a\_{ij} \times b\_{jk}

![](figs/matrix_multiplication.png)

Source: `wikimedia.org`

## 13.17 Matrix product algorithm

``` python
# input
matA = np.array(...).reshape(N,P)
matA = np.array(...).reshape(P,Q)
# output
matC = np.zeros((N,Q))
# algorithm
for i in range(N):
  for k in range(Q):
    for j in range(P):
      matC[i,k] += matA[i,j] * matB[j,k]
```

**Exercise:** parallel algorithm?

## 13.18 (naive) Parallel matrix product

``` python
# input
matA = np.array(...).reshape(N,P)
matA = np.array(...).reshape(P,Q)
# output
matC = np.zeros((N,Q))
# algorithm
@parallel
for i in range(N):
  for k in range(Q):
    for j in range(P):
      matC[i,k] += matA[i,j] * matB[j,k]
```

## 13.19 Divide-and-conquer procedure

- Divide output and input matrices into blocks:

C = \begin{bmatrix} C\_{11} & C\_{12} \\ C\_{21} & C\_{22} \\ \end{bmatrix},\\ A = \begin{bmatrix} A\_{11} & A\_{12} \\ A\_{21} & A\_{22} \\ \end{bmatrix},\\ B = \begin{bmatrix} B\_{11} & B\_{12} \\ B\_{21} & B\_{22} \\ \end{bmatrix}

- Compute C = A \times B by blocks:

\begin{darray}{rcl} \begin{bmatrix} C\_{11} & C\_{12} \\ C\_{21} & C\_{22} \\ \end{bmatrix} & = & \begin{bmatrix} A\_{11} & A\_{12} \\ A\_{21} & A\_{22} \\ \end{bmatrix} \begin{bmatrix} B\_{11} & B\_{12} \\ B\_{21} & B\_{22} \\ \end{bmatrix} \\ & = & \begin{bmatrix} A\_{11} B\_{11} + A\_{12} B\_{21} & A\_{11} B\_{12} + A\_{12} B\_{22}\\ A\_{21} B\_{11} + A\_{22} B\_{21} & A\_{21} B\_{12} + A\_{22} B\_{22}\\ \end{bmatrix} \end{darray}

- **Possible parallelization over sub-block products** A\_{ik} \times B\_{kj} and then **over result sums** \rightarrow see also “tiled implementation”

## 13.20 Fibonacci sequence

**Initialization:** f_0 = 0, f_1 = 1

**Iteration:** f_i = f\_{i-1} + f\_{i-2} for any i \geq 2

**Sequence:** 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, …

**Algorithm:**

``` python
n = 100
fib = np.zeros(100)
fib[0] = 0
fib[1] = 1
for i in range(2,n):
    res[i] = res[i-1] + res[i-2]
```

- Parallel version? (*NO!*) (at least not directly)
- \rightarrow result i depends of result from previous iterations (i-1 and i-2)
- \rightarrow dependency between iterations

## 13.21 Markov chain

Markov chain: sequence of random variables (X_i)\_{i\>1} such that \mathbb{P}(X_i = x_i \vert X_1 = x_1, X_2 = x_2, \dots , X\_{i-1} = x\_{i-1}) = \mathbb{P}(X_i = x_i \vert X\_{i-1} = x\_{i-1})

X_i\in S where S is the **state space**

Example:

- two states E and A, i.e S = \\A, E\\

- transition probability matrix:

\begin{array}{cl} \begin{array}{cc} A & E \end{array} \\ \left(\begin{array}{cc} 0.6 & 0.4 \\ 0.3 & 0.7 \\ \end{array}\right) & \begin{array}{l} A \\ E \end{array} \end{array}

![](figs/markov_chain.png)

[wikimedia.org](https://commons.wikimedia.org/wiki/Category:Markov_chains)

## 13.22 Markov chain simulation algorithm

1.  Pick an initial state X_0 = x with x\in S

2.  For in in 1,\dots, N:

    - Simulate X_i\in S from the probability distribution given by state X\_{i-1}

For the simulation:

- If X\_{i-1} = A then \mathbb{P}(X_i = A) = 0.6 and \mathbb{P}(X_i = E) = 0.4
- If X\_{i-1} = E then \mathbb{P}(X_i = A) = 0.7 and \mathbb{P}(X_i = E) = 0.3

**Exercise:** parallel algorithm?

NO!

# 14 Conclusion

## 14.1 Take home message

- **Parallel computing** can be used to **run** computations **faster** (i.e. save time)

- Relationship between **time gain** and number of tasks run in parallel is **not linear**

- Potential **bottlenecks** leading to potential performance loss:

  - management of parallel tasks
  - overhead for computing resource access
  - overhead for memory access
  - concurrent memory access by parallel tasks

Pelcat, Maxime. 2010. “Prototypage Rapide Et génération de Code Pour DSP Multi-Coeurs Appliqués à La Couche Physique Des Stations de Base 3GPP LTE.” PhD thesis, INSA de Rennes.

Robey, R., and Y. Zamora. 2021. *Parallel and High Performance Computing*. Manning. <https://www.manning.com/books/parallel-and-high-performance-computing>.

[^1]: the size of the block depends on the size of the cache
