# References

Author

Affiliations

François-David Collin [](mailto:francois-david.collin@umontpellier.fr)

CNRS

IMAG

Paul-Valéry Montpellier 3 University
