# Distributed models examples

Author

Affiliations

François-David Collin [](mailto:francois-david.collin@umontpellier.fr)

CNRS

IMAG

Paul-Valéry Montpellier 3 University

# Prerequisites

You will need to install `dask[complete]` and `graphviz` packages.

# Initialization

Code

``` python
from dask.distributed import LocalCluster
cluster = LocalCluster(n_workers=8, threads_per_worker=1)          # Fully-featured local Dask cluster
client = cluster.get_client()
client
```

    /Users/fradav/Documents/Dev/Python/Cours-programmation-MIASHS-2025/.venv/lib/python3.13/site-packages/distributed/node.py:187: UserWarning:

    Port 8787 is already in use.
    Perhaps you already have a cluster running?
    Hosting the HTTP server on port 61351 instead

### Client

Client-27bdab8c-8a02-11f0-9396-e9b4bfe5b177

|  |  |
|:---|:---|
| **Connection method:** Cluster object | **Cluster type:** distributed.LocalCluster |
| **Dashboard:** [http://127.0.0.1:61351/status](http://127.0.0.1:61351/status) |  |

### Cluster Info

### LocalCluster

3a8144b0

|  |  |
|:---|:---|
| **Dashboard:** [http://127.0.0.1:61351/status](http://127.0.0.1:61351/status) | **Workers:** 8 |
| **Total threads:** 8 | **Total memory:** 64.00 GiB |
| **Status:** running | **Using processes:** True |

### Scheduler Info

### Scheduler

Scheduler-defd704c-6fa1-425f-8bde-cccb79bcafa7

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:61352 | **Workers:** 0 |
| **Dashboard:** [http://127.0.0.1:61351/status](http://127.0.0.1:61351/status) | **Total threads:** 0 |
| **Started:** Just now | **Total memory:** 0 B |

### Workers

#### Worker: 0

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:61371 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:61373/status](http://127.0.0.1:61373/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:61355 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-sv6exyfy |  |

#### Worker: 1

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:61377 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:61379/status](http://127.0.0.1:61379/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:61357 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-61t5drhx |  |

#### Worker: 2

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:61372 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:61375/status](http://127.0.0.1:61375/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:61359 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-et4tu157 |  |

#### Worker: 3

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:61378 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:61381/status](http://127.0.0.1:61381/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:61361 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-2w58v0w8 |  |

#### Worker: 4

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:61384 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:61385/status](http://127.0.0.1:61385/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:61363 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-uw572jxk |  |

#### Worker: 5

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:61383 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:61386/status](http://127.0.0.1:61386/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:61365 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-jwr3p2oj |  |

#### Worker: 6

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:61390 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:61393/status](http://127.0.0.1:61393/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:61367 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-1ss6dzpz |  |

#### Worker: 7

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:61389 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:61391/status](http://127.0.0.1:61391/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:61369 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-af3461ju |  |

## Distributed prime numbers

Let’s revive our functions

Code

``` python
import math

def check_prime(n):
    if n % 2 == 0:
        return False
    for i in range(3, int(math.sqrt(n)) + 1, 2):
        if n % i == 0:
            return False
    return True
```

Code

``` python
def chunks(lst, n):
    """Yield successive n-sized chunks from lst."""
    for i in range(0, len(lst), n):
        yield lst[i:i + n]
```

Code

``` python
import numpy as np

def find_primes(r):
    return np.array(list(filter(check_prime,r)))
```

### First steps

1.  Complete with the correct Dask code the function below which:
    - takes a maximum number `N` and a `chunksize` as arguments
    - creates a Dask `array` with numbers from 1 to `N` split into `chunksize` chunks
    - maps the `find_primes` function to each chunk
    - returns the resulting Dask array

See [Dask Array documentation](https://docs.dask.org/en/stable/array.html).

``` python
import dask.array as da

def calculate_primes(N,chunksize):
    arr = ...
    return arr....
```

2.  Benchmark it for

``` python
N = 5000000
```

Code

``` python
import dask.array as da

def calculate_primes(N, workers):
    arr = da.arange(1, N, chunks=N // workers)
    # Apply find_primes to each chunk using map_blocks
    return arr.map_blocks(find_primes)
```

Code

``` python
N = 5000000
```

Code

``` python
compute_graph = calculate_primes(N,8)
compute_graph
```

[TABLE]

Code

``` python
%timeit compute_graph.compute()
```

    2.4 s ± 13.7 ms per loop (mean ± std. dev. of 7 runs, 1 loop each)

3.  Visualize the computation graph

Code

``` python
compute_graph.visualize()
```

![](05_0_Distributed_models-sol_files/figure-html/cell-10-output-1.png)

# An embarrassingly parallel example : distributed Monte-Carlo computing of \pi

If we sample randomly a bunch of N points in the unity square, and counts all points N_I verifying the condition

x^2 + y^2 \le 1 which means they are in the upper right quarter of a disk.

We have this convergence

\lim\_{N\to\infty} 4\frac{N_I}{N} = \pi

![](attachment:hpp2_0901.png)

### 2. Write the function which :

- takes a number of estimates `nbr_estimates` as argument
- samples them in the \[(0,0),(1,1)\] unity square
- returns the number of points inside the disk quarter

``` python
def estimate_nbr_points_in_quarter_circle(nbr_estimates):
    ...
    return nbr_trials_in_quarter_unit_circle
```

Code

``` python
import random

def estimate_nbr_points_in_quarter_circle(nbr_estimates):
    nbr_trials_in_quarter_unit_circle = 0
    for step in range(int(nbr_estimates)):
        x = random.uniform(0, 1)
        y = random.uniform(0, 1)
        is_in_unit_circle = x * x + y * y <= 1.0
        nbr_trials_in_quarter_unit_circle += is_in_unit_circle
    return nbr_trials_in_quarter_unit_circle
```

Code

``` python
4*estimate_nbr_points_in_quarter_circle(1e4)/1e4
```

    3.1472

### 3. Make it distributed

- Wraps the previous function in \`\`\`python import dask.bag as db

  def calculate_pi_distributed(nnodes,nbr_samples_in_total) … return estimated_pi \`\`\`

- `nnodes` will use only `nnodes` partitions for bag and split the number of estimates for each worker nodes into `nnodes` blocks.

- Try it on `1e8` samples and benchmark it on 1 to 8 nodes. (use [`time`](https://docs.python.org/3/library/time.html#time.time))

- Plot the performance gain over one node and comment the plot.

See [Dask Bag documentation](https://docs.dask.org/en/stable/bag.html).

Code

``` python
import dask.bag as db

def calculate_pi_distributed(nnodes, nbr_samples_in_total):

    nbr_samples_per_worker = int(nbr_samples_in_total // nnodes)
    samples = [nbr_samples_per_worker] * nnodes
    bag = db.from_sequence(samples, npartitions=nnodes)
    results = bag.map(estimate_nbr_points_in_quarter_circle).compute()
    return sum(results) * 4 / nbr_samples_in_total
```

Code

``` python
calculate_pi_distributed(8,1e7)
```

    3.1422736

Code

``` python
import time

N = 1e8
cluster_times = []
pis = []
for nbr_parallel_blocks in range(1,9):
    print(f"With {nbr_parallel_blocks} node(s): ")
    t1 = time.time()
    pi_estimate = calculate_pi_distributed(nbr_parallel_blocks,N)
    total_time = time.time() - t1
    print(f"\tPi estimate : {pi_estimate}")
    print("\tTime : {:.2f}s".format(total_time))
    cluster_times.append(total_time)
    pis.append(pi_estimate)
```

    With 1 node(s): 
        Pi estimate : 3.14165708
        Time : 14.62s
    With 2 node(s): 
        Pi estimate : 3.14139812
        Time : 7.37s
    With 3 node(s): 
        Pi estimate : 3.1412766
        Time : 4.90s
    With 4 node(s): 
        Pi estimate : 3.14173344
        Time : 3.72s
    With 5 node(s): 
        Pi estimate : 3.14147744
        Time : 3.04s
    With 6 node(s): 
        Pi estimate : 3.14153544
        Time : 2.56s
    With 7 node(s): 
        Pi estimate : 3.14165244
        Time : 2.26s
    With 8 node(s): 
        Pi estimate : 3.1415182
        Time : 2.06s

Code

``` python
import plotly.express as px

speedups_cores = [cluster_times[0]/cluster_times[i] for i in range(8)]
px.line(y=speedups_cores,x=range(1,9),
        labels={"x":"Number of cores",
                "y":"Speedup over 1 core"},
       width=600)
```

\Longrightarrow We see a near perfect linear scalability.

## Reuse

[CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)
