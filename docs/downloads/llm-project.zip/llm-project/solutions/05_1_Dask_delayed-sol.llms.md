# Dask `delayed` App

Author

Affiliations

François-David Collin [](mailto:francois-david.collin@umontpellier.fr)

CNRS

IMAG

Paul-Valéry Montpellier 3 University

![Dask logo\\](https://docs.dask.org/en/latest/_images/dask_horizontal.svg)

# dask.delayed - parallelize any code

What if you don’t have an array or dataframe? Instead of having blocks where the function is applied to each block, you can decorate functions with `@delayed` and *have the functions themselves be lazy*.

This is a simple way to use `dask` to parallelize existing codebases or build [complex systems](https://blog.dask.org/2018/02/09/credit-models-with-dask).

**Related Documentation**

- [Delayed documentation](https://docs.dask.org/en/latest/delayed.html)
- [Delayed screencast](https://www.youtube.com/watch?v=SHqFmynRxVU)
- [Delayed API](https://docs.dask.org/en/latest/delayed-api.html)
- [Delayed examples](https://examples.dask.org/delayed.html)
- [Delayed best practices](https://docs.dask.org/en/latest/delayed-best-practices.html)

As we’ll see in the [distributed scheduler notebook](05_distributed.ipynb), Dask has several ways of executing code in parallel. We’ll use the distributed scheduler by creating a `dask.distributed.Client`. For now, this will provide us with some nice diagnostics. We’ll talk about schedulers in depth later.

### Iniatilization of the ipyparallel/dask interface

Code

``` python
from dask.distributed import LocalCluster
cluster = LocalCluster(n_workers=8, threads_per_worker=1)          # Fully-featured local Dask cluster
client = cluster.get_client()
client
```

### Client

Client-22840e50-8a06-11f0-9826-eb16a79cfd2a

|  |  |
|:---|:---|
| **Connection method:** Cluster object | **Cluster type:** distributed.LocalCluster |
| **Dashboard:** [http://127.0.0.1:8787/status](http://127.0.0.1:8787/status) |  |

### Cluster Info

### LocalCluster

3ed4c178

|  |  |
|:---|:---|
| **Dashboard:** [http://127.0.0.1:8787/status](http://127.0.0.1:8787/status) | **Workers:** 8 |
| **Total threads:** 8 | **Total memory:** 64.00 GiB |
| **Status:** running | **Using processes:** True |

### Scheduler Info

### Scheduler

Scheduler-395a2fcf-a870-4509-b233-dfc6ced26d9a

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:53172 | **Workers:** 0 |
| **Dashboard:** [http://127.0.0.1:8787/status](http://127.0.0.1:8787/status) | **Total threads:** 0 |
| **Started:** Just now | **Total memory:** 0 B |

### Workers

#### Worker: 0

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:53191 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:53195/status](http://127.0.0.1:53195/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:53175 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-ags1xa5f |  |

#### Worker: 1

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:53192 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:53196/status](http://127.0.0.1:53196/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:53177 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-oq1yww3b |  |

#### Worker: 2

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:53193 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:53199/status](http://127.0.0.1:53199/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:53179 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-5gadzo7h |  |

#### Worker: 3

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:53201 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:53205/status](http://127.0.0.1:53205/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:53181 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-zun66gdw |  |

#### Worker: 4

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:53194 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:53202/status](http://127.0.0.1:53202/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:53183 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-luetz6iv |  |

#### Worker: 5

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:53204 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:53209/status](http://127.0.0.1:53209/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:53185 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-x7rg_q1e |  |

#### Worker: 6

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:53206 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:53211/status](http://127.0.0.1:53211/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:53187 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-6dpoots7 |  |

#### Worker: 7

|  |  |
|:---|:---|
| **Comm:** tcp://127.0.0.1:53208 | **Total threads:** 1 |
| **Dashboard:** [http://127.0.0.1:53213/status](http://127.0.0.1:53213/status) | **Memory:** 8.00 GiB |
| **Nanny:** tcp://127.0.0.1:53189 |  |
| **Local directory:** /var/folders/p0/pqx517ld19nf9ybmf7rbv4bc0000gn/T/dask-scratch-space/worker-hz2h1ad2 |  |

## A Typical Workflow

Typically if a workflow contains a for-loop it can benefit from delayed. The following example outlines a read-transform-write:

``` python
import dask
    
@dask.delayed
def process_file(filename):
    data = read_a_file(filename)
    data = do_a_transformation(data)
    destination = f"results/{filename}"
    write_out_data(data, destination)
    return destination

results = []
for filename in filenames:
    results.append(process_file(filename))
    
dask.compute(results)
```

## Basics

First let’s make some toy functions, `inc` and `add`, that sleep for a while to simulate work. We’ll then time running these functions normally.

In the next section we’ll parallelize this code.

Code

``` python
from time import sleep


def inc(x):
    sleep(1)
    return x + 1


def add(x, y):
    sleep(1)
    return x + y
```

We time the execution of this normal code using the `%%time` magic, which is a special function of the Jupyter Notebook.

Code

``` python
%%time
# This takes three seconds to run because we call each
# function sequentially, one after the other

x = inc(1)
y = inc(2)
z = add(x, y) 
```

    CPU times: user 135 ms, sys: 81.5 ms, total: 216 ms
    Wall time: 3.01 s

### Parallelize with the `dask.delayed` decorator

Those two increment calls *could* be called in parallel, because they are totally independent of one-another.

We’ll make the `inc` and `add` functions lazy using the `dask.delayed` decorator. When we call the delayed version by passing the arguments, exactly as before, the original function isn’t actually called yet - which is why the cell execution finishes very quickly. Instead, a *delayed object* is made, which keeps track of the function to call and the arguments to pass to it.

Code

``` python
import dask


@dask.delayed
def inc(x):
    sleep(1)
    return x + 1


@dask.delayed
def add(x, y):
    sleep(1)
    return x + y
```

Code

``` python
%%time
# This runs immediately, all it does is build a graph

x = inc(1)
y = inc(2)
z = add(x, y)
```

    CPU times: user 460 μs, sys: 210 μs, total: 670 μs
    Wall time: 656 μs

This ran immediately, since nothing has really happened yet.

To get the result, call `compute`. Notice that this runs faster than the original code.

Code

``` python
%%time
# This actually runs our computation using a local thread pool

z.compute()
```

    CPU times: user 112 ms, sys: 62 ms, total: 174 ms
    Wall time: 2.03 s

    5

## What just happened?

The `z` object is a lazy `Delayed` object. This object holds everything we need to compute the final result, including references to all of the functions that are required and their inputs and relationship to one-another. We can evaluate the result with `.compute()` as above or we can visualize the task graph for this value with `.visualize()`.

Code

``` python
z
```

    Delayed('add-669bced3-3a9e-4f30-9447-f2cd217473e7')

Code

``` python
# Look at the task graph for `z`
z.visualize()
```

![](05_1_Dask_delayed-sol_files/figure-html/cell-9-output-1.png)

Notice that this includes the names of the functions from before, and the logical flow of the outputs of the `inc` functions to the inputs of `add`.

### Some questions to consider:

- Why did we go from 3s to 2s? Why weren’t we able to parallelize down to 1s?
- What would have happened if the inc and add functions didn’t include the `sleep(1)`? Would Dask still be able to speed up this code?
- What if we have multiple outputs or also want to get access to x or y?

## Exercise: Parallelize a for loop

`for` loops are one of the most common things that we want to parallelize. Use `dask.delayed` on `inc` and `sum` to parallelize the computation below:

Code

``` python
data = [1, 2, 3, 4, 5, 6, 7, 8] 
```

Code

``` python
%%time
# Sequential code


def inc(x):
    sleep(1)
    return x + 1


results = []
for x in data:
    y = inc(x)
    results.append(y)

total = sum(results)
```

    CPU times: user 367 ms, sys: 226 ms, total: 593 ms
    Wall time: 8.02 s

Code

``` python
total
```

    44

Code

``` python
%%time
# Your parallel code here...
```

    CPU times: user 2 μs, sys: 1 μs, total: 3 μs
    Wall time: 5.01 μs

Code

``` python
%%time

@dask.delayed
def inc(x):
    sleep(1)
    return x + 1


results = []
for x in data:
    y = inc(x)
    results.append(y)

total = dask.delayed(sum)(results)
print("Before computing:", total)  # Let's see what type of thing total is
result = total.compute()
print("After computing :", result)  # After it's computed
```

    Before computing: Delayed('sum-2e99c6d8-4f13-45ad-b55b-d87c84c3b9f4')
    After computing : 44
    CPU times: user 60.4 ms, sys: 33.8 ms, total: 94.2 ms
    Wall time: 1.02 s

How do the graph visualizations compare with the given solution, compared to a version with the `sum` function used directly rather than wrapped with `delayed`? Can you explain the latter version? You might find the result of the following expression illuminating

``` python
inc(1) + inc(2)
```

Code

``` python
(inc(1) + inc(2)).visualize()
```

![](05_1_Dask_delayed-sol_files/figure-html/cell-15-output-1.png)

Code

``` python
sum([inc(1),inc(2),inc(3)]).visualize()
```

![](05_1_Dask_delayed-sol_files/figure-html/cell-16-output-1.png)

Code

``` python
total.visualize()
```

![](05_1_Dask_delayed-sol_files/figure-html/cell-17-output-1.png)

## Putting it all together with a the producer-consumer pattern

## Introduction with a simple producer-consumer example

We’ll try to reproduce the producer/consumer code from asynchronous application with `asyncio` or `threading` but with `dask.delayed` and compute

``` python
from dask import delayed, compute
from dask.distributed import Queue, print
from time import sleep

queue = Queue()
...
```

Code

``` python
from dask import delayed, compute
from dask.distributed import Queue, print
from time import sleep

queue = Queue()

@delayed
def produce(queue, n):
    print("producing {} items".format(n))
    for x in range(1, n + 1):
        # simulate i/o operation using sleep
        sleep(1)
        # produce an item
        print("producing {}/{}".format(x, n))
        item = str(x)
        # put the item in the queue
        queue.put(item)

    # indicate the producer is done
    queue.put(None)
    return n

@delayed
def consume(queue):
    consumed = 0
    print("consuming items")
    while True:
        # wait for an item from the producer
        item = queue.get()
        if item is None:
            # the producer emits None to indicate that it is done
            break

        # process the item
        print("consuming {}".format(item))
        consumed += 1
    return consumed

compute(
    produce(queue, 5), 
    consume(queue)
)
```

    (5, 5)

## Exercise: Parallelize a for-loop code with control flow

Often we want to delay only *some* functions, running a few of them immediately. This is especially helpful when those functions are fast and help us to determine what other slower functions we should call. This decision, to delay or not to delay, is usually where we need to be thoughtful when using `dask.delayed`.

In the example below we iterate through a list of inputs. If that input is even then we want to call `inc`. If the input is odd then we want to call `double`. This `is_even` decision to call `inc` or `double` has to be made immediately (not lazily) in order for our graph-building Python code to proceed.

Code

``` python
def double(x):
    sleep(1)
    return 2 * x

def inc(x):
    sleep(1)
    return x + 1

def is_even(x):
    return not x % 2


data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
```

Code

``` python
%%time
# Sequential code

results = []
for x in data:
    if is_even(x):
        y = double(x)
    else:
        y = inc(x)
    results.append(y)

total = sum(results)
print(total)
```

    90
    CPU times: user 461 ms, sys: 371 ms, total: 832 ms
    Wall time: 10 s

``` python
%%time
# Your parallel code here...
# TODO: parallelize the sequential code above using dask.delayed
# You will need to delay some functions, but not all
```

Code

``` python
@dask.delayed
def double(x):
    sleep(1)
    return 2 * x

@dask.delayed
def inc(x):
    sleep(1)
    return x + 1

results = []
for x in data:
    if is_even(x):  # even
        y = double(x)
    else:  # odd
        y = inc(x)
    results.append(y)

total = sum(results)
```

Code

``` python
%time total.compute()
```

    CPU times: user 100 ms, sys: 70.9 ms, total: 171 ms
    Wall time: 2.04 s

    90

Code

``` python
total.visualize()
```

![](05_1_Dask_delayed-sol_files/figure-html/cell-23-output-1.png)

### Some questions to consider:

- What are other examples of control flow where we can’t use delayed?

- What would have happened if we had delayed the evaluation of `is_even(x)` in the example above?

- What are your thoughts on delaying `sum`? This function is both computational but also fast to run.

- Example of control flow with we can’t use delayed : conditional loops, recursive functions

- Nothing, we have to compute it immediately for branching

- Delaying sum isn’t worth the graph walk overload

## Exercise: Parallelize a Pandas Groupby Reduction

In this exercise we read several CSV files and perform a groupby operation in parallel. We are given sequential code to do this and parallelize it with `dask.delayed`.

The computation we will parallelize is to compute the mean departure delay per airport from some historical flight data. We will do this by using `dask.delayed` together with `pandas`. In a future section we will do this same exercise with `dask.dataframe`.

## Create data

Run this code to prep some data.

This downloads and extracts some historical flight data for flights out of NYC between 1990 and 2000. The data is originally from [here](http://stat-computing.org/dataexpo/2009/the-data.html).

Code

``` python
import os
import requests

os.makedirs("data", exist_ok=True)
code_url = "https://raw.githubusercontent.com/dask/dask-tutorial/main/prep.py"
with open("prep.py", "wb") as f:
    f.write(requests.get(code_url).content)
%run prep.py -d flights
```

### Inspect data

Code

``` python
sorted(os.listdir(os.path.join("data", "nycflights")))
```

    ['1990.csv',
     '1991.csv',
     '1992.csv',
     '1993.csv',
     '1994.csv',
     '1995.csv',
     '1996.csv',
     '1997.csv',
     '1998.csv',
     '1999.csv']

### Read one file with `pandas.read_csv` and compute mean departure delay

Code

``` python
import pandas as pd

df = pd.read_csv(os.path.join("data", "nycflights", "1990.csv"))
df.head()
```

|  | Year | Month | DayofMonth | DayOfWeek | DepTime | CRSDepTime | ArrTime | CRSArrTime | UniqueCarrier | FlightNum | ... | AirTime | ArrDelay | DepDelay | Origin | Dest | Distance | TaxiIn | TaxiOut | Cancelled | Diverted |
|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|
| 0 | 1990 | 1 | 1 | 1 | 1621.0 | 1540 | 1747.0 | 1701 | US | 33 | ... | NaN | 46.0 | 41.0 | EWR | PIT | 319.0 | NaN | NaN | 0 | 0 |
| 1 | 1990 | 1 | 2 | 2 | 1547.0 | 1540 | 1700.0 | 1701 | US | 33 | ... | NaN | -1.0 | 7.0 | EWR | PIT | 319.0 | NaN | NaN | 0 | 0 |
| 2 | 1990 | 1 | 3 | 3 | 1546.0 | 1540 | 1710.0 | 1701 | US | 33 | ... | NaN | 9.0 | 6.0 | EWR | PIT | 319.0 | NaN | NaN | 0 | 0 |
| 3 | 1990 | 1 | 4 | 4 | 1542.0 | 1540 | 1710.0 | 1701 | US | 33 | ... | NaN | 9.0 | 2.0 | EWR | PIT | 319.0 | NaN | NaN | 0 | 0 |
| 4 | 1990 | 1 | 5 | 5 | 1549.0 | 1540 | 1706.0 | 1701 | US | 33 | ... | NaN | 5.0 | 9.0 | EWR | PIT | 319.0 | NaN | NaN | 0 | 0 |

5 rows × 23 columns

Code

``` python
# What is the schema?
df.dtypes
```

    Year                   int64
    Month                  int64
    DayofMonth             int64
    DayOfWeek              int64
    DepTime              float64
    CRSDepTime             int64
    ArrTime              float64
    CRSArrTime             int64
    UniqueCarrier         object
    FlightNum              int64
    TailNum              float64
    ActualElapsedTime    float64
    CRSElapsedTime         int64
    AirTime              float64
    ArrDelay             float64
    DepDelay             float64
    Origin                object
    Dest                  object
    Distance             float64
    TaxiIn               float64
    TaxiOut              float64
    Cancelled              int64
    Diverted               int64
    dtype: object

Code

``` python
# What originating airports are in the data?
df.Origin.unique()
```

    array(['EWR', 'LGA', 'JFK'], dtype=object)

Code

``` python
# Mean departure delay per-airport for one year
df.groupby("Origin").DepDelay.mean()
```

    Origin
    EWR     9.168411
    JFK    11.857274
    LGA     8.560045
    Name: DepDelay, dtype: float64

### Sequential code: Mean Departure Delay Per Airport

The above cell computes the mean departure delay per-airport for one year. Here we expand that to all years using a sequential for loop.

Code

``` python
from glob import glob

filenames = sorted(glob(os.path.join("data", "nycflights", "*.csv")))
```

Code

``` python
filenames
```

    ['data/nycflights/1990.csv',
     'data/nycflights/1991.csv',
     'data/nycflights/1992.csv',
     'data/nycflights/1993.csv',
     'data/nycflights/1994.csv',
     'data/nycflights/1995.csv',
     'data/nycflights/1996.csv',
     'data/nycflights/1997.csv',
     'data/nycflights/1998.csv',
     'data/nycflights/1999.csv']

Code

``` python
%%time

sums = []
counts = []
for fn in filenames:
    # Read in file
    df = pd.read_csv(fn)

    # Groupby origin airport
    by_origin = df.groupby("Origin")

    # Sum of all departure delays by origin
    total = by_origin.DepDelay.sum()

    # Number of flights by origin
    count = by_origin.DepDelay.count()

    # Save the intermediates
    sums.append(total)
    counts.append(count)

# Combine intermediates to get total mean-delay-per-origin
total_delays = sum(sums)
n_flights = sum(counts)
mean = total_delays / n_flights
```

    CPU times: user 1.1 s, sys: 174 ms, total: 1.27 s
    Wall time: 1.25 s

Code

``` python
mean
```

    Origin
    EWR    10.295469
    JFK    10.351299
    LGA     7.431142
    Name: DepDelay, dtype: float64

### Parallelize the code above

Use `dask.delayed` to parallelize the code above. Some extra things you will need to know.

1.  Methods and attribute access on delayed objects work automatically, so if you have a delayed object you can perform normal arithmetic, slicing, and method calls on it and it will produce the correct delayed calls.

2.  Calling the `.compute()` method works well when you have a single output. When you have multiple outputs you might want to use the `dask.compute` function. This way Dask can share the intermediate values.

So your goal is to parallelize the code above (which has been copied below) using `dask.delayed`. You may also want to visualize a bit of the computation to see if you’re doing it correctly.

``` python
%%time
# your code here
```

Code

``` python
%%time

# This is just one possible solution, there are
# several ways to do this using `dask.delayed`


@dask.delayed
def read_file(filename):
    # Read in file
    return pd.read_csv(filename)


sums = []
counts = []
for fn in filenames:
    # Delayed read in file
    df = read_file(fn)

    # Groupby origin airport
    by_origin = df.groupby("Origin")

    # Sum of all departure delays by origin
    total = by_origin.DepDelay.sum()

    # Number of flights by origin
    count = by_origin.DepDelay.count()

    # Save the intermediates
    sums.append(total)
    counts.append(count)

# Combine intermediates to get total mean-delay-per-origin
total_delays = sum(sums)
n_flights = sum(counts)
mean, *_ = dask.compute(total_delays / n_flights)
```

    CPU times: user 35.7 ms, sys: 19 ms, total: 54.6 ms
    Wall time: 499 ms

Code

``` python
# ensure the results still match
mean
```

    Origin
    EWR    10.295469
    JFK    10.351299
    LGA     7.431142
    Name: DepDelay, dtype: float64

### Some questions to consider:

- How much speedup did you get? Is this how much speedup you’d expect?
- Experiment with where to call `compute`. What happens when you call it on `sums` and `counts`? What happens if you wait and call it on `mean`?
- Experiment with delaying the call to `sum`. What does the graph look like if `sum` is delayed? What does the graph look like if it isn’t?
- Can you think of any reason why you’d want to do the reduction one way over the other?

### Learn More

Visit the [Delayed documentation](https://docs.dask.org/en/latest/delayed.html). In particular, this [delayed screencast](https://www.youtube.com/watch?v=SHqFmynRxVU) will reinforce the concepts you learned here and the [delayed best practices](https://docs.dask.org/en/latest/delayed-best-practices.html) document collects advice on using `dask.delayed` well.

Some improvements by actual parallelization of file reading, but we’re limited by IO throughput.

Code

``` python
dask.compute(sums)
```

    ([Origin
      EWR    1062573.0
      JFK     554956.0
      LGA     898351.0
      Name: DepDelay, dtype: float64,
      Origin
      EWR    776235.0
      JFK    389520.0
      LGA    577681.0
      Name: DepDelay, dtype: float64,
      Origin
      EWR    976045.0
      JFK    422302.0
      LGA    659255.0
      Name: DepDelay, dtype: float64,
      Origin
      EWR    1119295.0
      JFK     351783.0
      LGA     617911.0
      Name: DepDelay, dtype: float64,
      Origin
      EWR    1322649.0
      JFK     448715.0
      LGA     765889.0
      Name: DepDelay, dtype: float64,
      Origin
      EWR    948014.0
      JFK    457644.0
      LGA    686691.0
      Name: DepDelay, dtype: float64,
      Origin
      EWR    1548420.0
      JFK     680821.0
      LGA     799150.0
      Name: DepDelay, dtype: float64,
      Origin
      EWR    1250156.0
      JFK     366344.0
      LGA     562100.0
      Name: DepDelay, dtype: float64,
      Origin
      EWR    1295784.0
      JFK     358156.0
      LGA     701016.0
      Name: DepDelay, dtype: float64,
      Origin
      EWR    1432011.0
      JFK     392279.0
      LGA     971872.0
      Name: DepDelay, dtype: float64],)

Code

``` python
dask.compute(counts)
```

    ([Origin
      EWR    115895
      JFK     46803
      LGA    104947
      Name: DepDelay, dtype: int64,
      Origin
      EWR    112234
      JFK     41832
      LGA    100882
      Name: DepDelay, dtype: int64,
      Origin
      EWR    113801
      JFK     42030
      LGA    101553
      Name: DepDelay, dtype: int64,
      Origin
      EWR    110286
      JFK     41280
      LGA    101122
      Name: DepDelay, dtype: int64,
      Origin
      EWR    112516
      JFK     42243
      LGA     98571
      Name: DepDelay, dtype: int64,
      Origin
      EWR    106398
      JFK     45412
      LGA     96810
      Name: DepDelay, dtype: int64,
      Origin
      EWR    114019
      JFK     42688
      LGA     92367
      Name: DepDelay, dtype: int64,
      Origin
      EWR    118228
      JFK     39246
      LGA     94042
      Name: DepDelay, dtype: int64,
      Origin
      EWR    116028
      JFK     41865
      LGA     91025
      Name: DepDelay, dtype: int64,
      Origin
      EWR    120046
      JFK     43844
      LGA     92948
      Name: DepDelay, dtype: int64],)

Code

``` python
%%time

# This is just one possible solution, there are
# several ways to do this using `dask.delayed`


@dask.delayed
def read_file(filename):
    # Read in file
    return pd.read_csv(filename)


sums = []
counts = []
for fn in filenames:
    # Delayed read in file
    df = read_file(fn)

    # Groupby origin airport
    by_origin = df.groupby("Origin")

    # Sum of all departure delays by origin
    total = by_origin.DepDelay.sum()

    # Number of flights by origin
    count = by_origin.DepDelay.count()

    # Save the intermediates
    sums.append(total)
    counts.append(count)

# Combine intermediates to get total mean-delay-per-origin
total_delays = dask.delayed(sum)(sums)
n_flights = dask.delayed(sum)(counts)
mean, *_ = dask.compute(total_delays / n_flights)
```

    CPU times: user 27.6 ms, sys: 8.12 ms, total: 35.8 ms
    Wall time: 346 ms

Code

``` python
dask.delayed(sum)(sums).visualize()
```

![](05_1_Dask_delayed-sol_files/figure-html/cell-39-output-1.png)

Code

``` python
sum(sums).visualize()
```

![](05_1_Dask_delayed-sol_files/figure-html/cell-40-output-1.png)

*Solution*. Delaying the sum could be interesting in case to make more balanced loads between tasks.

## Close the Client

Before moving on to the next exercise, make sure to close your client or stop this kernel.

Code

``` python
client.close()
```

## Reuse

[CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)
