# python-doc — Documentation Python officielle, locale

Référence locale des modules Python utilisés dans les chapitres `Courses/` du cours
« Programmation avancée et calcul parallèle », pour la **recherche locale par les
tuteurs LLM** : en S2, les étudiants peuvent tester les profils « Ask » / « Write » du
tuteur dans Zed, dont l'agent dispose de `read_file`, `grep`, `list_directory`,
`fetch`, etc. Une doc locale se greppe et se lit sans aller sur le réseau.

## Contenu

Copie des sources officielles de la doc CPython, branche **3.12**
(`Doc/library/*.rst` du dépôt `python/cpython`), converties en markdown GitHub
(`pandoc -f rst -t gfm`). Régénération reproductible :

```sh
python3 fetch_docs.py        # relit les .rst, réécrit library/*.md
```

`fetch_docs.py` épinglé sur `BRANCH = "3.12"` ; le monter à chaque nouvelle version de
Python cible.

| Fichier | Contenu | Chapitre du cours |
|---|---|---|
| `asyncio*.md` (5) | boucles d'événements, tâches, streams, synchro, sous-processus | `01_asynchronous` |
| `concurrent.futures.md` | pools thread/process | `00_intro-parallelism`, `01_asynchronous` |
| `threading.md` | threads, verrous | `00_intro-parallelism`, `02_ipc-locks` |
| `multiprocessing.md` | processus, pipes, files, managers, verrous | `02_ipc-locks`, `03_distributed` |
| `multiprocessing.shared_memory.md` | mémoire partagée | `02_ipc-locks`, `03_distributed` |
| `queue.md` | files thread-safe | `00_intro-parallelism`, `02_ipc-locks` |
| `socket.md` | sockets | `02_ipc-locks`, `03_distributed` |
| `subprocess.md` | sous-processus | `00_intro-parallelism`, `02_ipc-locks` |

## Limites

Les chapitres `04_simd`, `05_gpu` et `06_webgpu` reposent sur des bibliothèques en
dehors de la bibliothèque standard Python (numpy, numba, cupy, WebGPU), dont la doc
officielle n'est **pas** incluse ici. À ajouter à la demande si un tutorat en a besoin :

- numpy : https://numpy.org/doc/stable/
- numba : https://numba.pydata.org/numba-doc/latest/
- cupy : https://docs.cupy.dev/en/stable/
- WebGPU : https://www.w3.org/TR/webgpu/
