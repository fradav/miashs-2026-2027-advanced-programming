#!/usr/bin/env python3
"""Fetch the official CPython library docs into python-doc/ as markdown, so an
LLM tutor (S2 — Ask/Write profile in Zed) can grep/read them locally instead of
fetching from the network.

Sources: the reStructuredText doc source of the official CPython repo
(raw.githubusercontent.com/python/cpython/<branch>/Doc/library/*.rst), converted
to GitHub-flavored markdown with pandoc (must be installed).

Usage:  python3 fetch_docs.py

The version branch is pinned here; bump BRANCH and re-run to refresh on a new
Python release. SIMD/GPU/WebGPU have no Python-stdlib reference documentation,
so they are intentionally not fetched here (see README.md).
"""
import socket
import subprocess
import urllib.request
from pathlib import Path

BRANCH = "3.12"
BASE = f"https://raw.githubusercontent.com/python/cpython/{BRANCH}/Doc/library"

# module -> course chapter(s) that need it, for the README mapping
MODULES = [
    # asyncio family  ->  module "asynchronous" (01_asynchronous)
    "asyncio",
    "asyncio-task",
    "asyncio-stream",
    "asyncio-sync",
    "asyncio-subprocess",
    # threads / processes / IPC / locks  ->  modules "intro-parallelism",
    # "ipc-locks" (02_ipc-locks) and "distributed" (03_distributed)
    "concurrent.futures",
    "threading",
    "multiprocessing",
    "multiprocessing.shared_memory",
    "queue",
    "socket",
    "subprocess",
]


def clean(text: str) -> str:
    """Post-process pandoc's RST->markdown output: drop the raw HTML <div>
    directives and the stray "!" pandoc puts on module-name code spans in H1s
    (e.g. "# `!threading` ---" -> "# `threading` ---")."""
    import re
    text = re.sub(r"<div\b[^>]*>\n?", "", text)
    text = re.sub(r"</div>\n?", "", text)
    text = re.sub(r"(?m)^# `!([\w.]+)`", r"# `\1`", text)
    return text


def main() -> None:
    out = Path(__file__).resolve().parent / "library"
    out.mkdir(parents=True, exist_ok=True)
    socket.setdefaulttimeout(25)
    failed = []
    for name in MODULES:
        url = f"{BASE}/{name}.rst"
        try:
            with urllib.request.urlopen(url) as resp:
                rst = resp.read().decode("utf-8")
        except Exception as exc:  # noqa: BLE001 — report and keep going
            failed.append((name, repr(exc)))
            print(f"FETCH FAIL {name}: {exc!r}")
            continue
        try:
            proc = subprocess.run(
                ["pandoc", "-f", "rst", "-t", "gfm"],
                input=rst,
                text=True,
                check=True,
                capture_output=True,
            )
        except Exception as exc:  # noqa: BLE001
            failed.append((name, repr(exc)))
            print(f"PANDOC FAIL {name}: {exc!r}")
            continue
        (out / f"{name}.md").write_text(clean(proc.stdout), encoding="utf-8")
        print(f"OK {name}: {len(rst)} bytes rst -> {out / (name + '.md')}")
    print("FAILURES:", failed if failed else "none")


if __name__ == "__main__":
    main()
